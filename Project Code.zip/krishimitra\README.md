# KrishiMitra - AI-Powered Soil & Crop Advisory

An intelligent agricultural advisory web application that helps Indian farmers analyze soil quality, get crop recommendations, and access farming guidance through AI-powered analysis and voice assistance in 8 regional languages.

## Features

- **AI Soil Analysis** - Upload soil images for instant analysis using Claude AI (soil type, pH, moisture, crop recommendations)
- **Voice Assistant** - Ask farming questions via speech in English, Telugu, and Hindi using Web Speech API
- **8-Language Support** - Full UI translations: English, Telugu, Hindi, Tamil, Kannada, Marathi, Gujarati, Punjabi
- **3 Themes** - Dark (default), Light, and Forest green theme with CSS variable system
- **Weather Widget** - Auto-detected location with current conditions and 3-day forecast via Open-Meteo
- **Soil Types Guide** - Comprehensive guide to 8 Indian soil types with characteristics and best crops
- **NPK Leaf Guide** - Visual color-based nutrient deficiency identification guide
- **Seasonal Advisories** - Kharif/Rabi season tips, pest alerts, and farming best practices
- **Mobile-First Design** - Responsive UI with bottom navigation on mobile, sidebar on desktop

## Tech Stack

- **Frontend**: React 18 + Vite 5 + Tailwind CSS 3
- **Backend**: Node.js + Express 4
- **Database**: SQLite (better-sqlite3)
- **AI**: Anthropic Claude API (claude-sonnet-4-20250514)
- **Weather**: Open-Meteo API (free, no key required)
- **Voice**: Browser Web Speech API (no external service)

## Prerequisites

- Node.js 18+ (tested with Node 20)
- npm 8+
- Anthropic API key

## Setup

1. **Clone and install dependencies:**

```bash
cd krishimitra
npm install
cd server && npm install && cd ..
cd client && npm install && cd ..
```

2. **Configure environment:**

```bash
cp .env.example .env
```

Edit `.env` and add your Anthropic API key:
```
ANTHROPIC_API_KEY=sk-ant-...
PORT=5000
```

3. **Start development servers:**

```bash
npm run dev
```

This starts both:
- Backend server at `http://localhost:5000`
- Frontend dev server at `http://localhost:5173`

4. **Open the app:**

Visit `http://localhost:5173` in your browser.

## Production Build

```bash
npm run build    # Builds the React client
npm start        # Starts Express serving the built client
```

## Project Structure

```
krishimitra/
├── client/                    # React + Vite frontend
│   ├── src/
│   │   ├── components/        # Reusable UI components
│   │   ├── context/           # React contexts (Auth, Theme, Language)
│   │   ├── data/              # Static data (soil types, NPK, advisories, FAQ)
│   │   ├── lib/               # Utilities (API client)
│   │   ├── pages/             # Page components (9 pages)
│   │   ├── translations.js    # 8-language translation strings
│   │   ├── themes.js          # Theme metadata
│   │   ├── App.jsx            # Root component with routing
│   │   └── main.jsx           # Entry point
│   ├── index.html
│   ├── tailwind.config.js
│   └── vite.config.js
├── server/                    # Express backend
│   ├── routes/                # API routes (auth, soil, voice, user, weather)
│   ├── middleware/            # Auth middleware
│   ├── services/              # Claude AI service with retry logic
│   ├── db.js                  # SQLite database setup
│   └── index.js               # Express server entry
├── .env.example
└── package.json               # Root with concurrently for dev
```

## API Endpoints

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | /api/auth/login | No | Login with phone number |
| GET | /api/user/profile | Yes | Get user profile with scan count |
| PUT | /api/user/profile | Yes | Update language/theme preferences |
| POST | /api/soil/analyze | Yes | Analyze soil image via Claude AI |
| GET | /api/soil/history | Yes | Get paginated scan history |
| GET | /api/soil/analysis/:id | Yes | Get single analysis with image |
| POST | /api/voice/query | Yes | Send text query to Claude AI |
| GET | /api/weather/location | No | Get location from IP for weather |

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| ANTHROPIC_API_KEY | Yes | Your Anthropic API key |
| PORT | No | Server port (default: 5000) |

## Notes

- **Authentication**: Simple phone-number login with server-generated tokens. No passwords or OTP.
- **Voice Recognition**: Uses browser Web Speech API — works best in Chrome/Edge. Falls back to text input in unsupported browsers.
- **Weather**: Uses ip-api.com for geolocation (proxied through Express to avoid mixed-content issues) and Open-Meteo for weather data.
- **Error Handling**: All Claude API calls include automatic retry with exponential backoff on 529 (overloaded) responses.
- **Database**: SQLite file (`krishimitra.db`) is created automatically in the server directory on first run.
