import { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import faqData from '../data/faqData';

const QUICK_HELP = [
  { icon: 'photo_camera', title: 'Scan Soil', desc: 'Take a photo to analyze your soil type and get crop recommendations', link: '/soil-scan' },
  { icon: 'eco', title: 'Leaf Analysis', desc: 'Upload a leaf photo to check NPK nutrient levels', link: '/npk-guide' },
  { icon: 'mic', title: 'Ask AI', desc: 'Use voice or text to ask farming questions', link: '/voice' },
];

export default function Help() {
  const { t } = useLanguage();
  const [openIndex, setOpenIndex] = useState(null);

  const toggle = (i) => setOpenIndex(openIndex === i ? null : i);

  return (
    <div className="py-6 px-4 max-w-lg mx-auto space-y-8">
      {/* Hero Banner */}
      <div className="relative rounded-2xl overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800&q=80"
          alt="Farming support"
          className="w-full h-44 object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/40 to-black/20" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-6">
          <div className="w-14 h-14 rounded-2xl bg-white/15 backdrop-blur-sm flex items-center justify-center mb-4 border border-white/10">
            <span className="material-symbols-outlined text-white text-2xl">support_agent</span>
          </div>
          <h1 className="text-2xl font-black text-white tracking-tight drop-shadow-lg">
            {t('help.title')}
          </h1>
          <p className="text-sm text-white/70 mt-2 max-w-xs leading-relaxed">
            Find answers to common questions or reach out to our support team
          </p>
        </div>
      </div>

      {/* Quick Help Cards */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <span className="w-2 h-2 rounded-full bg-accent shrink-0" />
          <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-text-secondary">
            Quick Help
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {QUICK_HELP.map((item) => (
            <a
              key={item.title}
              href={item.link}
              className="bg-surface-card ghost-border rounded-2xl p-5 hover:bg-surface-hover hover:border-accent/20 transition-all duration-200 group block"
            >
              <div className="w-11 h-11 rounded-xl bg-accent/10 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                <span className="material-symbols-outlined text-accent" style={{ fontSize: '22px' }}>{item.icon}</span>
              </div>
              <p className="text-sm font-bold text-text-primary mb-1">{item.title}</p>
              <p className="text-xs text-text-secondary leading-relaxed">{item.desc}</p>
            </a>
          ))}
        </div>
      </div>

      {/* FAQ Section */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <span className="w-2 h-2 rounded-full bg-accent shrink-0" />
          <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-text-secondary">
            {t('help.faq')}
          </p>
        </div>
        <div className="space-y-3">
          {faqData.map((item, i) => (
            <div
              key={i}
              className="rounded-2xl overflow-hidden ghost-border bg-surface-card transition-all duration-200 hover:shadow-md"
            >
              <button
                onClick={() => toggle(i)}
                className="w-full flex items-center justify-between px-5 py-4 hover:bg-surface-hover transition-colors text-left gap-3"
              >
                <div className="flex items-center gap-3">
                  <span className="material-symbols-outlined text-accent text-lg shrink-0">help</span>
                  <span className="text-sm font-semibold text-text-primary leading-snug">
                    {item.question}
                  </span>
                </div>
                <span
                  className={`material-symbols-outlined text-text-secondary text-xl flex-shrink-0 transition-transform duration-300 ${
                    openIndex === i ? 'rotate-180' : ''
                  }`}
                >
                  expand_more
                </span>
              </button>
              <div
                className={`overflow-hidden transition-all duration-300 ease-in-out ${
                  openIndex === i ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
                }`}
              >
                <div className="px-5 py-4 bg-surface-lowest text-sm text-text-secondary leading-relaxed ghost-border border-l-0 border-r-0 border-b-0">
                  {item.answer}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Contact Section */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <span className="w-2 h-2 rounded-full bg-accent shrink-0" />
          <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-text-secondary">
            {t('help.contact')}
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <a
            href="tel:1800XXXXXXX"
            className="flex flex-col items-center gap-3 p-5 bg-surface-card rounded-2xl hover:bg-surface-hover transition-all duration-200 ghost-border group hover:border-blue-500/20"
          >
            <div className="w-14 h-14 rounded-2xl bg-blue-500/10 flex items-center justify-center group-hover:scale-110 transition-transform">
              <span className="material-symbols-outlined text-blue-500 text-2xl">call</span>
            </div>
            <div className="text-center">
              <p className="text-sm font-semibold text-text-primary">{t('help.phone')}</p>
              <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-text-secondary mt-1">1800-XXX-XXXX</p>
            </div>
          </a>

          <a
            href="mailto:support@krishimitra.app"
            className="flex flex-col items-center gap-3 p-5 bg-surface-card rounded-2xl hover:bg-surface-hover transition-all duration-200 ghost-border group hover:border-amber-500/20"
          >
            <div className="w-14 h-14 rounded-2xl bg-amber-500/10 flex items-center justify-center group-hover:scale-110 transition-transform">
              <span className="material-symbols-outlined text-amber-500 text-2xl">mail</span>
            </div>
            <div className="text-center">
              <p className="text-sm font-semibold text-text-primary">{t('help.email')}</p>
              <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-text-secondary mt-1">support@krishimitra.app</p>
            </div>
          </a>

          <a
            href="https://wa.me/919876543210"
            target="_blank"
            rel="noopener noreferrer"
            className="flex flex-col items-center gap-3 p-5 bg-surface-card rounded-2xl hover:bg-surface-hover transition-all duration-200 ghost-border group hover:border-green-500/20"
          >
            <div className="w-14 h-14 rounded-2xl bg-green-500/10 flex items-center justify-center group-hover:scale-110 transition-transform">
              <span className="material-symbols-outlined text-green-500 text-2xl">chat</span>
            </div>
            <div className="text-center">
              <p className="text-sm font-semibold text-text-primary">{t('help.whatsapp')}</p>
              <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-text-secondary mt-1">+91 98765 43210</p>
            </div>
          </a>
        </div>
      </div>

      {/* App Version */}
      <p className="text-center text-[10px] font-bold uppercase tracking-[0.15em] text-text-secondary pt-2 pb-4">
        KrishiMitra v1.0.0
      </p>
    </div>
  );
}
