import { useLanguage } from '../context/LanguageContext';
import advisoryData from '../data/advisoryData';
import AdvisoryCard from '../components/AdvisoryCard';

const SEASON_IMAGES = {
  Kharif: 'https://images.unsplash.com/photo-1536657464919-892534f60d6e?w=800&q=80',
  Rabi: 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=800&q=80',
  Zaid: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800&q=80',
};

function getCurrentSeason() {
  const month = new Date().getMonth();
  if (month >= 5 && month <= 9) return { name: 'Kharif', period: 'June - October', icon: 'thunderstorm' };
  if (month >= 9 && month <= 2) return { name: 'Rabi', period: 'October - March', icon: 'ac_unit' };
  return { name: 'Zaid', period: 'March - June', icon: 'wb_sunny' };
}

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export default function Advisory() {
  const { t } = useLanguage();
  const season = getCurrentSeason();
  const currentMonth = new Date().getMonth();

  return (
    <div className="py-8">
      {/* Hero Banner with seasonal photo */}
      <div className="relative rounded-2xl overflow-hidden mb-8">
        <img
          src={SEASON_IMAGES[season.name]}
          alt={`${season.name} season`}
          className="w-full h-48 md:h-60 object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/40 to-transparent" />
        <div className="absolute inset-0 flex flex-col justify-center px-6 md:px-10">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-green-300">
              Seasonal Advisories
            </span>
          </div>
          <h1 className="text-2xl md:text-4xl font-black tracking-tight text-white drop-shadow-lg mb-2">
            {t('advisory.title')}
          </h1>
          <div className="flex items-center gap-3 mt-2">
            <div className="w-10 h-10 rounded-xl bg-white/10 backdrop-blur-sm flex items-center justify-center border border-white/10">
              <span className="material-symbols-outlined text-white text-xl">{season.icon}</span>
            </div>
            <div>
              <p className="text-white font-bold text-base">{season.name} Season</p>
              <p className="text-white/60 text-xs">{season.period}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Month Calendar Bar */}
      <div className="bg-surface-card ghost-border rounded-2xl p-4 mb-8 overflow-x-auto">
        <div className="flex items-center gap-2 mb-3 px-1">
          <span className="w-1.5 h-1.5 rounded-full bg-accent" />
          <span className="text-[10px] font-bold uppercase tracking-widest text-text-secondary">Season Calendar</span>
        </div>
        <div className="flex gap-2 min-w-max">
          {MONTHS.map((month, i) => {
            const isKharif = i >= 5 && i <= 9;
            const isRabi = i >= 9 || i <= 2;
            const isZaid = i >= 2 && i <= 5;
            const isCurrent = i === currentMonth;

            let seasonColor = 'bg-surface-lowest text-text-secondary';
            if (isKharif) seasonColor = 'bg-blue-500/10 text-blue-400';
            if (isRabi) seasonColor = 'bg-amber-500/10 text-amber-400';
            if (isZaid) seasonColor = 'bg-green-500/10 text-green-400';

            return (
              <div
                key={month}
                className={`flex flex-col items-center px-3 py-2 rounded-xl transition-all ${seasonColor} ${
                  isCurrent ? 'ring-2 ring-accent shadow-md scale-105' : ''
                }`}
              >
                <span className="text-[10px] font-bold uppercase tracking-wider">{month}</span>
                {isCurrent && <span className="w-1 h-1 rounded-full bg-accent mt-1" />}
              </div>
            );
          })}
        </div>
      </div>

      {/* Advisory Cards */}
      <div className="space-y-4">
        {advisoryData.map((advisory) => (
          <AdvisoryCard key={advisory.id} advisory={advisory} />
        ))}
      </div>
    </div>
  );
}
