import { useState, useEffect, useRef } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { apiFetch } from '../lib/api';
import ImageUploader from '../components/ImageUploader';
import AnalysisResult from '../components/AnalysisResult';
import AnalysisHistory from '../components/AnalysisHistory';
import LoadingSpinner from '../components/LoadingSpinner';

const HINTS = [
  'Identifying soil type...',
  'Checking nutrient levels...',
  'Generating crop recommendations...',
  'Almost done...',
];

export default function SoilAnalysis() {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState('scan');
  const [imageBase64, setImageBase64] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [hintIndex, setHintIndex] = useState(0);
  const hintInterval = useRef(null);

  useEffect(() => {
    if (analyzing) {
      setHintIndex(0);
      hintInterval.current = setInterval(() => {
        setHintIndex((prev) => (prev + 1) % HINTS.length);
      }, 2000);
    } else {
      clearInterval(hintInterval.current);
    }
    return () => clearInterval(hintInterval.current);
  }, [analyzing]);

  const handleAnalyze = async () => {
    if (!imageBase64) return;
    setAnalyzing(true);
    setError('');
    setResult(null);
    try {
      const data = await apiFetch('/soil/analyze', {
        method: 'POST',
        body: { image: imageBase64 },
      });
      setResult(data.result || data);
    } catch (err) {
      setError(err.message || 'Analysis failed. Please try again.');
    } finally {
      setAnalyzing(false);
    }
  };

  const handleReset = () => {
    setImageBase64(null);
    setResult(null);
    setError('');
  };

  const tabs = [
    { key: 'scan', label: t('soil.newScan'), icon: 'document_scanner' },
    { key: 'history', label: t('soil.history'), icon: 'history' },
  ];

  return (
    <div className="py-8 max-w-2xl mx-auto">
      {/* Hero Banner */}
      <div className="relative rounded-2xl overflow-hidden mb-8">
        <img
          src="https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=800&q=80"
          alt="Soil analysis"
          className="w-full h-36 md:h-44 object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/40 to-transparent" />
        <div className="absolute inset-0 flex flex-col justify-center px-6 md:px-8">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-green-300">
              AI-Powered Scanning
            </span>
          </div>
          <h1 className="text-2xl md:text-3xl font-black tracking-tight text-white drop-shadow-lg">
            {t('soil.title')}
          </h1>
        </div>
      </div>

      {/* Tab Toggle */}
      <div className="flex gap-1 p-1.5 rounded-full ghost-border bg-surface-card mb-8 w-fit">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`flex items-center gap-2 px-6 py-2.5 text-sm font-bold rounded-full transition-all duration-300 ${
              activeTab === tab.key
                ? 'bg-accent text-accent-on shadow-md shadow-accent/20'
                : 'text-text-secondary hover:text-text-primary hover:bg-surface-hover'
            }`}
          >
            <span className="material-symbols-outlined text-lg">{tab.icon}</span>
            {tab.label}
          </button>
        ))}
      </div>

      {/* New Scan Tab */}
      {activeTab === 'scan' && (
        <div className="space-y-6">
          {!analyzing && !result && (
            <>
              <ImageUploader onImageSelect={setImageBase64} />

              {error && (
                <div className="flex items-center gap-2 justify-center p-3 rounded-xl bg-error/5 border border-error/10">
                  <span className="material-symbols-outlined text-error text-lg">warning</span>
                  <p className="text-error text-sm font-medium">{error}</p>
                </div>
              )}

              <button
                onClick={handleAnalyze}
                disabled={!imageBase64}
                className="w-full py-4 rounded-full text-accent-on font-bold text-base bg-accent hover:bg-accent/90 transition-all duration-300 disabled:opacity-30 disabled:cursor-not-allowed shadow-lg shadow-accent/20 hover:shadow-accent/30 hover:shadow-xl"
              >
                <span className="flex items-center justify-center gap-2">
                  <span className="material-symbols-outlined">science</span>
                  {t('soil.analyze')}
                </span>
              </button>
            </>
          )}

          {analyzing && (
            <div className="flex flex-col items-center justify-center py-20 bg-surface-card rounded-2xl ghost-border relative overflow-hidden">
              <div className="absolute inset-0 opacity-5">
                <img src="https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=600&q=30" alt="" className="w-full h-full object-cover" />
              </div>
              <LoadingSpinner size="lg" text={HINTS[hintIndex]} />
            </div>
          )}

          {!analyzing && result && (
            <div className="space-y-5">
              <AnalysisResult result={result} />
              <button
                onClick={handleReset}
                className="w-full py-4 rounded-full font-bold ghost-border text-text-primary hover:bg-surface-hover hover:border-accent/30 transition-all duration-300 flex items-center justify-center gap-2"
              >
                <span className="material-symbols-outlined">refresh</span>
                {t('soil.scanAnother')}
              </button>
            </div>
          )}
        </div>
      )}

      {activeTab === 'history' && <AnalysisHistory />}
    </div>
  );
}
