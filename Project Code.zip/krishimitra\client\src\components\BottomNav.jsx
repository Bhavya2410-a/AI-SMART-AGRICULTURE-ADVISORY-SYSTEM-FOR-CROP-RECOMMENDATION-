import { NavLink } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

const bottomItems = [
  { to: '/', labelKey: 'nav.dashboard', icon: 'dashboard' },
  { to: '/soil-scan', labelKey: 'nav.soilScan', icon: 'search' },
  { to: '/voice', labelKey: 'nav.voice', icon: 'mic' },
  { to: '/profile', labelKey: 'nav.profile', icon: 'person' },
  { to: '/help', labelKey: 'nav.help', icon: 'help' },
];

export default function BottomNav() {
  const { t } = useLanguage();

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-surface-card/80 backdrop-blur-lg rounded-t-2xl ghost-border border-b-0 border-l-0 border-r-0">
      <div className="flex items-center justify-around px-2 py-2">
        {bottomItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === '/'}
            className={({ isActive }) =>
              `flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-xl transition-all duration-200 ${
                isActive
                  ? 'bg-accent-container text-accent-on'
                  : 'text-text-secondary hover:text-text-primary'
              }`
            }
          >
            <span className="material-symbols-outlined text-[22px]">{item.icon}</span>
            <span className="text-[10px] font-medium leading-tight">{t(item.labelKey)}</span>
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
