function renderMarkdown(text) {
  return text
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)/g, '<em>$1</em>')
    .replace(/`(.+?)`/g, '<code class="bg-black/10 px-1.5 py-0.5 rounded text-xs font-mono">$1</code>')
    .replace(/\n/g, '<br />');
}

export default function ChatBubble({ message }) {
  const isUser = message.role === 'user';

  const time = new Date(message.timestamp).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  });

  if (isUser) {
    return (
      <div className="flex justify-end mb-4 animate-slide-up">
        <div className="relative max-w-[78%] md:max-w-[65%]">
          {/* Bubble tail */}
          <div className="absolute top-0 -right-1.5 w-3 h-3 overflow-hidden">
            <div className="w-4 h-4 bg-accent-container rotate-45 transform origin-bottom-left rounded-sm" />
          </div>
          <div className="bg-accent-container text-accent-on rounded-2xl rounded-tr-none px-4 py-3 shadow-sm shadow-accent/10">
            <p className="whitespace-pre-wrap break-words text-[14px] leading-[1.6]">
              {message.text}
            </p>
            <div className="flex items-center gap-1 justify-end mt-1 -mb-0.5">
              <span className="text-[10px] text-accent-on/50 font-medium">{time}</span>
              <span className="material-symbols-outlined text-accent-on/50" style={{ fontSize: '15px' }}>done_all</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex justify-start mb-4 animate-slide-up group">
      {/* Avatar */}
      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-accent/20 to-accent/10 flex items-center justify-center mr-2.5 mt-0.5 shrink-0 shadow-sm">
        <span className="material-symbols-outlined text-accent" style={{ fontSize: '16px' }}>eco</span>
      </div>

      <div className="relative max-w-[78%] md:max-w-[65%]">
        {/* Bubble tail */}
        <div className="absolute top-0 -left-1.5 w-3 h-3 overflow-hidden">
          <div className="w-4 h-4 bg-surface-elevated rotate-45 transform origin-bottom-right rounded-sm" />
        </div>
        <div className="bg-surface-elevated text-text-primary rounded-2xl rounded-tl-none px-4 py-3 ghost-border shadow-sm">
          {/* Sender label */}
          <p className="text-[11px] font-bold text-accent mb-1">KrishiMitra</p>
          <div
            className="whitespace-pre-wrap break-words text-[14px] leading-[1.6] [&_strong]:font-bold [&_em]:italic"
            dangerouslySetInnerHTML={{ __html: renderMarkdown(message.text) }}
          />
          <div className="flex items-center justify-end mt-1 -mb-0.5">
            <span className="text-[10px] text-text-secondary/50 font-medium">{time}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
