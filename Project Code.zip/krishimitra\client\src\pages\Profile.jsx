import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { apiFetch } from '../lib/api';
import themes from '../themes';

const LANGUAGES = [
  { code: 'en', name: 'English', native: 'English' },
  { code: 'te', name: 'Telugu', native: 'తెలుగు' },
  { code: 'hi', name: 'Hindi', native: 'हिन्दी' },
  { code: 'ta', name: 'Tamil', native: 'தமிழ்' },
  { code: 'kn', name: 'Kannada', native: 'ಕನ್ನಡ' },
  { code: 'mr', name: 'Marathi', native: 'मराठी' },
  { code: 'gu', name: 'Gujarati', native: 'ગુજરાતી' },
  { code: 'pa', name: 'Punjabi', native: 'ਪੰਜਾਬੀ' },
];

function maskPhone(phone) {
  if (!phone || phone.length < 6) return phone || '';
  return phone.slice(0, 2) + '****' + phone.slice(-4);
}

function formatDate(dateStr) {
  if (!dateStr) return '';
  return new Date(dateStr).toLocaleDateString('en-IN', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

export default function Profile() {
  const { t, language, setLanguage } = useLanguage();
  const { user, logout } = useAuth();
  const { theme, setTheme } = useTheme();
  const navigate = useNavigate();

  const [scanCount, setScanCount] = useState(0);

  useEffect(() => {
    apiFetch('/user/profile')
      .then((data) => {
        const profile = data?.user || data;
        setScanCount(profile?.scanCount ?? 0);
      })
      .catch(() => {});
  }, []);

  const handleLanguageChange = async (code) => {
    setLanguage(code);
    try {
      await apiFetch('/user/profile', {
        method: 'PUT',
        body: { language: code },
      });
    } catch {
      // silently fail
    }
  };

  const handleLogout = () => {
    if (window.confirm(t('profile.logoutConfirm'))) {
      logout();
      navigate('/login');
    }
  };

  const phoneFirstDigit = user?.phone ? user.phone[0] : '?';

  return (
    <div className="py-6 px-4 max-w-lg mx-auto space-y-6">
      {/* Profile Header with Banner */}
      <div className="bg-surface-card ghost-border rounded-2xl overflow-hidden">
        {/* Banner image */}
        <div className="relative h-28 overflow-hidden">
          <img
            src="https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800&q=80"
            alt=""
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/20 to-black/50" />
        </div>

        <div className="px-8 pb-8">
          {/* Avatar overlapping banner */}
          <div className="flex flex-col items-center -mt-12 relative z-10">
            <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-accent to-accent-container text-accent-on flex items-center justify-center text-3xl font-black ring-4 ring-surface-card shadow-xl">
              {phoneFirstDigit}
            </div>

            <p className="text-xl font-bold text-text-primary tracking-tight mt-4">
              {maskPhone(user?.phone)}
            </p>

            {/* Info chips */}
            <div className="flex flex-wrap justify-center gap-3 mt-3 text-sm text-text-secondary">
              <span className="flex items-center gap-1.5 bg-surface-lowest rounded-full px-3 py-1.5">
                <span className="material-symbols-outlined text-base text-accent">calendar_today</span>
                {formatDate(user?.created_at)}
              </span>
              <span className="flex items-center gap-1.5 bg-surface-lowest rounded-full px-3 py-1.5">
                <span className="material-symbols-outlined text-base text-accent">search</span>
                {scanCount} {t('profile.totalScans')}
              </span>
            </div>
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-2 gap-3 mt-6">
            <div className="bg-gradient-to-br from-accent/10 to-accent/5 border border-accent/10 rounded-2xl p-4 text-center">
              <p className="text-2xl font-black text-text-primary">{scanCount}</p>
              <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-text-secondary mt-1">Total Scans</p>
            </div>
            <div className="bg-gradient-to-br from-secondary/10 to-secondary/5 border border-secondary/10 rounded-2xl p-4 text-center">
              <p className="text-2xl font-black text-accent">{LANGUAGES.find(l => l.code === language)?.name?.slice(0, 2).toUpperCase() || 'EN'}</p>
              <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-text-secondary mt-1">Language</p>
            </div>
          </div>
        </div>
      </div>

      {/* Language Section */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <span className="w-2 h-2 rounded-full bg-accent shrink-0" />
          <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-text-secondary">
            {t('profile.language')}
          </p>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {LANGUAGES.map((lang) => (
            <button
              key={lang.code}
              onClick={() => handleLanguageChange(lang.code)}
              className={`rounded-2xl px-3 py-3.5 text-center transition-all duration-200 ghost-border group ${
                language === lang.code
                  ? 'border-accent bg-accent/5 shadow-sm shadow-accent/10'
                  : 'bg-surface-card hover:bg-surface-hover hover:border-accent/20'
              }`}
              style={language === lang.code ? { borderColor: 'var(--accent)' } : {}}
            >
              <span className="block text-base font-semibold text-text-primary group-hover:scale-105 transition-transform">
                {lang.native}
              </span>
              <span className="block text-[10px] font-bold text-text-secondary mt-1 uppercase tracking-[0.15em]">
                {lang.name}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Theme Section */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <span className="w-2 h-2 rounded-full bg-accent shrink-0" />
          <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-text-secondary">
            {t('profile.theme')}
          </p>
        </div>
        <div className="grid grid-cols-3 gap-3">
          {themes.map((th) => (
            <button
              key={th.id}
              onClick={() => setTheme(th.id)}
              className={`rounded-2xl px-3 py-4 flex flex-col items-center gap-3 transition-all duration-200 ghost-border group ${
                theme === th.id
                  ? 'border-accent bg-accent/5 shadow-sm shadow-accent/10'
                  : 'bg-surface-card hover:bg-surface-hover hover:border-accent/20'
              }`}
              style={theme === th.id ? { borderColor: 'var(--accent)' } : {}}
            >
              <div
                className="w-full h-12 rounded-xl group-hover:scale-105 transition-transform shadow-inner"
                style={{
                  background: `linear-gradient(135deg, ${th.color} 0%, ${th.dotColor} 100%)`,
                }}
              />
              <span className="text-xs font-semibold text-text-primary">{th.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Danger Zone */}
      <div className="ghost-border rounded-2xl p-6 border-error/20">
        <div className="flex items-center gap-2 mb-4">
          <span className="material-symbols-outlined text-error text-base">warning</span>
          <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-error/80">Danger Zone</p>
        </div>
        <button
          onClick={handleLogout}
          className="w-full py-3 rounded-full bg-error/10 text-error font-semibold text-sm hover:bg-error hover:text-white transition-all duration-300 flex items-center justify-center gap-2"
        >
          <span className="material-symbols-outlined text-xl">logout</span>
          {t('profile.logout')}
        </button>
      </div>
    </div>
  );
}
