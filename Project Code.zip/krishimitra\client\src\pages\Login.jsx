import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';

const HERO_IMG = 'https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=1400&q=80';
const ABOUT_IMG1 = 'https://images.unsplash.com/photo-1574943320219-553eb213f72d?w=600&q=80';
const ABOUT_IMG2 = 'https://images.unsplash.com/photo-1592982537447-6f2a6a0c7c18?w=600&q=80';
const TECH_IMG = 'https://images.unsplash.com/photo-1530836369250-ef72a3f5cda8?w=1200&q=80';
const FARMER1 = 'https://images.unsplash.com/photo-1605000797499-95a51c5269ae?w=200&q=80';
const FARMER2 = 'https://images.unsplash.com/photo-1595508064774-5ff825a75f39?w=200&q=80';

const features = [
  { icon: '📸', title: 'Precision Soil Analysis', desc: 'Using AI vision and satellite imagery, farmers can monitor fields in real-time, apply fertilizers efficiently, and reduce resource use.' },
  { icon: '💧', title: 'Efficient Irrigation Systems', desc: 'By integrating soil moisture sensors and weather data, farmers can ensure crops receive the right amount of water at the right time.' },
  { icon: '📊', title: 'AI & Data Analytics', desc: 'AI-driven models analyze historical and real-time data to predict pest infestations, detect crop diseases early, and recommend planting schedules.' },
  { icon: '🎙️', title: 'Multilingual Voice Assistant', desc: 'Ask farming questions in Telugu, Hindi, or English. Get expert advice through natural conversation with our AI advisor.' },
];

const stats = [
  { value: '8+', label: 'Indian Soil Types', desc: 'Comprehensive analysis of all major soil types found across India, from Alluvial to Laterite.' },
  { value: '85%', label: 'Crop Match Accuracy', desc: 'Our AI recommendation engine delivers precise crop suggestions matched to your specific soil and climate.' },
];

export default function Login() {
  const [phone, setPhone] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [scrollY, setScrollY] = useState(0);
  const { login } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const loginRef = useRef(null);

  useEffect(() => {
    requestAnimationFrame(() => setMounted(true));
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    const digits = phone.replace(/\D/g, '');
    if (digits.length !== 10) {
      setError(t('login.invalidPhone'));
      return;
    }
    setLoading(true);
    try {
      await login(digits);
      navigate('/', { replace: true });
    } catch (err) {
      setError(err.message || t('common.error'));
    } finally {
      setLoading(false);
    }
  };

  const scrollToLogin = () => {
    loginRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const formatPhone = (val) => {
    const digits = val.replace(/\D/g, '').slice(0, 10);
    if (digits.length > 5) return digits.slice(0, 5) + ' ' + digits.slice(5);
    return digits;
  };

  return (
    <div className="min-h-screen bg-surface overflow-x-hidden">
      {/* ===== NAVBAR ===== */}
      <nav
        className="fixed top-0 left-0 right-0 z-50 h-16 flex items-center justify-between px-6 md:px-12 transition-all duration-300"
        style={{
          backgroundColor: scrollY > 50 ? 'rgba(15, 20, 26, 0.9)' : 'transparent',
          backdropFilter: scrollY > 50 ? 'blur(16px)' : 'none',
          borderBottom: scrollY > 50 ? '1px solid rgba(134, 149, 133, 0.15)' : 'none',
        }}
      >
        <div className="flex items-center gap-2">
          <span className="text-xl">🌿</span>
          <span className="text-xl font-black text-accent tracking-tighter">KrishiMitra</span>
        </div>
        <div className="hidden md:flex items-center gap-8 text-sm text-text-secondary">
          <a href="#features" className="hover:text-text-primary transition-colors">Features</a>
          <a href="#about" className="hover:text-text-primary transition-colors">About</a>
          <a href="#technology" className="hover:text-text-primary transition-colors">Technology</a>
          <a href="#testimonials" className="hover:text-text-primary transition-colors">Stories</a>
        </div>
        <button
          onClick={scrollToLogin}
          className="bg-accent text-accent-on px-5 py-2 rounded-full text-sm font-bold hover:brightness-110 transition-all active:scale-95"
        >
          Login
        </button>
      </nav>

      {/* ===== HERO SECTION ===== */}
      <section className="relative h-screen min-h-[700px] flex items-end overflow-hidden">
        {/* Hero image with parallax */}
        <div className="absolute inset-0">
          <img
            src={HERO_IMG}
            alt="Lush green farmland at golden hour"
            className="w-full h-full object-cover"
            style={{ transform: `translateY(${scrollY * 0.3}px)` }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-surface via-surface/60 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-surface/80 to-transparent" />
        </div>

        <div className="relative z-10 w-full max-w-7xl mx-auto px-6 md:px-12 pb-20 md:pb-28">
          <div className="max-w-2xl">
            <span
              className="inline-block bg-surface-card/80 ghost-border text-text-secondary text-xs font-bold uppercase tracking-widest px-4 py-2 rounded-full mb-6 backdrop-blur-sm transition-all duration-700"
              style={{ opacity: mounted ? 1 : 0, transform: mounted ? 'translateY(0)' : 'translateY(20px)' }}
            >
              Sustainable Farming Tech
            </span>

            <h1
              className="text-4xl md:text-6xl lg:text-7xl font-black text-text-primary leading-[1.05] tracking-tight mb-6 transition-all duration-900"
              style={{ opacity: mounted ? 1 : 0, transform: mounted ? 'translateY(0)' : 'translateY(30px)', transitionDelay: '200ms' }}
            >
              Bringing Innovation to
              <br />Your Farming Journey.
            </h1>

            <p
              className="text-text-secondary text-lg md:text-xl max-w-lg leading-relaxed mb-8 transition-all duration-900"
              style={{ opacity: mounted ? 1 : 0, transform: mounted ? 'translateY(0)' : 'translateY(30px)', transitionDelay: '400ms' }}
            >
              From precision agriculture to sustainable practices, we help you grow more efficiently and profitably. Join us in transforming the way you farm!
            </p>

            <div
              className="flex items-center gap-4 transition-all duration-900"
              style={{ opacity: mounted ? 1 : 0, transform: mounted ? 'translateY(0)' : 'translateY(20px)', transitionDelay: '600ms' }}
            >
              <button
                onClick={scrollToLogin}
                className="bg-accent text-accent-on px-7 py-4 rounded-full text-sm font-bold flex items-center gap-2 hover:brightness-110 active:scale-95 transition-all group"
              >
                Get Started
                <span className="material-symbols-outlined text-lg bg-accent-on/20 rounded-full w-7 h-7 flex items-center justify-center group-hover:translate-x-1 transition-transform">arrow_forward</span>
              </button>
              <a href="#about" className="text-text-secondary hover:text-text-primary text-sm font-medium flex items-center gap-1 transition-colors">
                Learn More <span className="material-symbols-outlined text-base">arrow_forward</span>
              </a>
            </div>
          </div>

          {/* Mission card floating right */}
          <div
            className="hidden lg:block absolute right-12 bottom-28 w-80 bg-surface-card/80 backdrop-blur-md ghost-border rounded-2xl p-6 transition-all duration-1000"
            style={{ opacity: mounted ? 1 : 0, transform: mounted ? 'translateX(0)' : 'translateX(40px)', transitionDelay: '800ms' }}
          >
            <div className="flex items-center gap-2 mb-3">
              <div className="w-2 h-2 rounded-full bg-accent" />
              <span className="text-[10px] font-bold uppercase tracking-widest text-text-secondary">Our Mission</span>
            </div>
            <p className="text-text-primary text-sm leading-relaxed">
              To empower farmers with innovative tools and technology that enhance productivity, sustainability, and efficiency — shaping the future of farming.
            </p>
            <a href="#about" className="text-accent text-sm font-semibold mt-3 inline-flex items-center gap-1 hover:gap-2 transition-all">
              Learn More <span className="material-symbols-outlined text-base">arrow_forward</span>
            </a>
          </div>
        </div>
      </section>

      {/* ===== ABOUT SECTION ===== */}
      <section id="about" className="py-24 px-6 md:px-12 max-w-7xl mx-auto">
        <div className="flex flex-wrap gap-3 mb-12">
          {['About Us', 'Journey', 'Vision', 'Mission'].map((tab, i) => (
            <span key={i} className={`px-5 py-2 rounded-full text-sm font-medium transition-all cursor-pointer ${i === 0 ? 'bg-accent text-accent-on' : 'ghost-border text-text-secondary hover:bg-surface-hover'}`}>
              {tab}
            </span>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-2 h-2 rounded-full bg-accent" />
              <span className="text-[10px] font-bold uppercase tracking-widest text-text-secondary">Who We Are at KrishiMitra</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-black text-text-primary leading-tight tracking-tight mb-6">
              With years of expertise in both farming and tech, we're committed to helping farmers grow smarter and achieve better yields.
            </h2>
            <p className="text-text-secondary leading-relaxed mb-8">
              By combining innovation with sustainability, we empower farmers to increase productivity, reduce waste, and contribute to a healthier planet. Together, we are shaping the future of farming, ensuring it thrives for generations to come.
            </p>
            <button className="ghost-border text-text-primary px-6 py-3 rounded-full text-sm font-semibold hover:bg-surface-hover transition-all">
              Learn More
            </button>
          </div>

          {/* Stats + images */}
          <div className="grid grid-cols-2 gap-4">
            <div className="rounded-2xl overflow-hidden h-48">
              <img src={ABOUT_IMG1} alt="Farmer in field" className="w-full h-full object-cover" />
            </div>
            <div className="bg-surface-card ghost-border rounded-2xl p-6 flex flex-col justify-center">
              <span className="text-4xl font-black text-accent mb-1">{stats[0].value}</span>
              <span className="text-sm font-bold text-text-primary mb-2">{stats[0].label}</span>
              <p className="text-xs text-text-secondary leading-relaxed">{stats[0].desc}</p>
            </div>
            <div className="bg-surface-card ghost-border rounded-2xl p-6 flex flex-col justify-center">
              <span className="text-4xl font-black text-accent mb-1">{stats[1].value}</span>
              <span className="text-sm font-bold text-text-primary mb-2">{stats[1].label}</span>
              <p className="text-xs text-text-secondary leading-relaxed">{stats[1].desc}</p>
            </div>
            <div className="rounded-2xl overflow-hidden h-48">
              <img src={ABOUT_IMG2} alt="Sustainable farming" className="w-full h-full object-cover" />
            </div>
          </div>
        </div>
      </section>

      {/* ===== FEATURES SECTION ===== */}
      <section id="features" className="py-24 px-6 md:px-12 bg-surface-card">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-2 h-2 rounded-full bg-accent" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-text-secondary">Main Features</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-black text-text-primary tracking-tight mb-16 max-w-2xl leading-tight">
            Unlock the Future of Farming with Powerful Features Designed for Efficiency, Productivity, and Sustainability
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {features.map((f, i) => (
              <div key={i} className="bg-surface ghost-border rounded-xl p-6 flex gap-4 hover:border-accent/30 transition-all group">
                <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center text-2xl shrink-0 group-hover:scale-110 transition-transform">
                  {f.icon}
                </div>
                <div>
                  <h3 className="text-lg font-bold text-text-primary mb-2">{f.title}</h3>
                  <p className="text-sm text-text-secondary leading-relaxed">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== TECHNOLOGY SECTION ===== */}
      <section id="technology" className="py-24 px-6 md:px-12">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-2 h-2 rounded-full bg-accent" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-text-secondary">Our Technology</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-black text-text-primary tracking-tight mb-8">
            AI-Powered Precision Agriculture
          </h2>
          <div className="rounded-2xl overflow-hidden ghost-border relative">
            <img src={TECH_IMG} alt="Modern farming technology" className="w-full h-80 md:h-96 object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-surface via-transparent to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-8">
              <p className="text-text-primary text-lg font-medium max-w-2xl">
                Equipped with AI vision, soil sensors, and multi-spectral analysis, KrishiMitra captures real-time data about your fields, allowing farmers to monitor crop health, assess soil quality, and detect diseases early.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ===== TESTIMONIALS ===== */}
      <section id="testimonials" className="py-24 px-6 md:px-12 bg-surface-card">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="w-2 h-2 rounded-full bg-accent" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-text-secondary">Success Stories</span>
          </div>
          <blockquote className="text-xl md:text-2xl font-semibold text-text-primary leading-relaxed mb-10 italic">
            "Before using KrishiMitra, I struggled with unpredictable yields and high resource costs. Now, with AI-powered soil analytics, my farm's productivity has increased by 40%, and I use 30% less water."
          </blockquote>
          <div className="flex items-center justify-center gap-6">
            <div className="flex items-center gap-3">
              <img src={FARMER1} alt="Farmer" className="w-12 h-12 rounded-full object-cover border-2 border-accent/30" />
              <div className="text-left">
                <p className="text-sm font-bold text-text-primary">Ravi K.</p>
                <p className="text-xs text-text-secondary">Wheat Farmer, Punjab</p>
              </div>
            </div>
            <div className="w-px h-10 bg-border" />
            <div className="flex items-center gap-3">
              <img src={FARMER2} alt="Farmer" className="w-12 h-12 rounded-full object-cover border-2 border-accent/30" />
              <div className="text-left">
                <p className="text-sm font-bold text-text-primary">Lakshmi D.</p>
                <p className="text-xs text-text-secondary">Rice Grower, Telangana</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== LOGIN / CTA SECTION ===== */}
      <section ref={loginRef} id="login" className="py-24 px-6 md:px-12">
        <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-black text-text-primary tracking-tight leading-tight mb-4">
              Ready to Transform
              <br />Your <span className="text-accent">Farming?</span>
            </h2>
            <p className="text-text-secondary text-lg leading-relaxed mb-8">
              Join thousands of Indian farmers using AI to grow smarter. Just your phone number — no password needed.
            </p>
            <div className="flex flex-wrap gap-4">
              {['📸 AI Soil Analysis', '🌾 Crop Match', '🎙️ Voice in 3 Languages', '🌤️ Weather'].map((f, i) => (
                <span key={i} className="bg-surface-card ghost-border rounded-full px-4 py-2 text-sm text-text-secondary">
                  {f}
                </span>
              ))}
            </div>
          </div>

          {/* Login card */}
          <div className="bg-surface-elevated ghost-border rounded-2xl p-8">
            <h3 className="text-2xl font-bold text-text-primary mb-2">Get Started Free</h3>
            <p className="text-sm text-text-secondary mb-8">Enter your phone number to begin</p>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="text-[10px] font-bold text-text-secondary tracking-[0.15em] uppercase px-1 block mb-2">
                  {t('login.phoneLabel')}
                </label>
                <div className={`flex items-center bg-surface-lowest ghost-border rounded-xl overflow-hidden transition-all duration-300 ${error ? 'ring-1 ring-error/40' : 'focus-within:ring-1 focus-within:ring-accent/30'}`}>
                  <span className="pl-4 pr-3 text-text-secondary font-semibold border-r border-border">+91</span>
                  <input
                    type="tel"
                    inputMode="numeric"
                    value={formatPhone(phone)}
                    onChange={(e) => { setPhone(e.target.value.replace(/\D/g, '')); setError(''); }}
                    placeholder="00000 00000"
                    className="w-full bg-transparent text-text-primary py-4 px-3 placeholder:text-text-secondary/30 font-medium tracking-wider outline-none"
                    autoComplete="tel"
                  />
                </div>
              </div>

              {error && (
                <div className="flex items-center gap-2 text-error text-sm bg-error/10 px-3 py-2.5 rounded-lg">
                  <span className="material-symbols-outlined text-base">error</span>
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={loading || phone.replace(/\D/g, '').length < 10}
                className="w-full py-4 bg-gradient-to-r from-accent to-accent-container text-accent-on font-bold rounded-full flex items-center justify-center gap-2 transition-all active:scale-95 hover:brightness-110 disabled:opacity-40 disabled:cursor-not-allowed group"
                style={{ boxShadow: '0 8px 30px rgba(75, 226, 119, 0.15)' }}
              >
                {loading ? (
                  <><svg className="animate-spin h-5 w-5" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg> Connecting...</>
                ) : (
                  <><span>{t('login.submit')}</span><span className="material-symbols-outlined text-lg group-hover:translate-x-1 transition-transform">arrow_forward</span></>
                )}
              </button>
            </form>

            <div className="mt-6 pt-6 border-t border-border flex justify-between items-center">
              <div className="flex items-center gap-1.5 opacity-50">
                <span className="material-symbols-outlined text-[14px]">lock</span>
                <span className="text-[10px] font-bold tracking-widest uppercase text-text-secondary">Encrypted</span>
              </div>
              <div className="flex items-center gap-1.5 opacity-50">
                <span className="material-symbols-outlined text-[14px]">verified</span>
                <span className="text-[10px] font-bold tracking-widest uppercase text-text-secondary">No Password</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== FOOTER ===== */}
      <footer className="bg-surface-card border-t border-border py-10 px-6 md:px-12">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-lg">🌿</span>
              <span className="text-lg font-black text-accent tracking-tighter">KrishiMitra</span>
            </div>
            <p className="text-sm text-text-secondary max-w-md">
              Growing the Future of Farming with Innovation, Sustainability, and Smart Technology — Connecting Farmers to a Smarter Tomorrow.
            </p>
          </div>
          <div className="flex gap-4">
            {['Twitter', 'Facebook', 'Instagram', 'YouTube'].map((s) => (
              <a key={s} href="#" className="ghost-border text-text-secondary text-xs px-4 py-2 rounded-full hover:bg-surface-hover transition-colors">
                {s}
              </a>
            ))}
          </div>
        </div>
        <div className="max-w-7xl mx-auto mt-8 pt-6 border-t border-border flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-text-secondary/60">
          <span>© 2024 KrishiMitra AI. Precision Farming for a Greener Planet.</span>
          <div className="flex gap-6">
            <a href="#" className="hover:text-accent transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-accent transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-accent transition-colors">Support</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
