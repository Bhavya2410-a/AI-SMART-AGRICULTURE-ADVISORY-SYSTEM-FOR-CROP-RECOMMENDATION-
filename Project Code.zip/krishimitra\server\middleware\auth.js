const db = require('../db');

function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ success: false, error: 'Authentication required' });
  }

  const token = authHeader.split(' ')[1];
  const user = db.prepare('SELECT id, phone, language, theme, created_at FROM users WHERE token = ?').get(token);

  if (!user) {
    return res.status(401).json({ success: false, error: 'Invalid or expired token' });
  }

  req.user = user;
  next();
}

module.exports = authMiddleware;
