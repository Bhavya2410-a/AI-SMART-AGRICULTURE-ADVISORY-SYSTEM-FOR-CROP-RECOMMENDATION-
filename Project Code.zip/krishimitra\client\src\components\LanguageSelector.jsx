import { useLanguage } from '../context/LanguageContext';
import { languageNames } from '../translations';

export default function LanguageSelector() {
  const { language, setLanguage } = useLanguage();

  return (
    <select
      value={language}
      onChange={(e) => setLanguage(e.target.value)}
      className="bg-surface-lowest text-text-primary text-sm ghost-border rounded-lg px-2 py-1.5 outline-none focus:ring-1 focus:ring-accent cursor-pointer appearance-none"
      aria-label="Select language"
    >
      {Object.entries(languageNames).map(([code, name]) => (
        <option key={code} value={code}>
          {name}
        </option>
      ))}
    </select>
  );
}
