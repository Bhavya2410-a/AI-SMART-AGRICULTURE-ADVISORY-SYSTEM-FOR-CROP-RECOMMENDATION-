export default function StatCard({ label, value, materialIcon, iconColor = 'accent', subtitle }) {
  const colorMap = {
    accent: {
      gradient: 'from-accent/15 to-accent/5',
      iconBg: 'bg-accent/20',
      text: 'text-accent',
      glow: 'shadow-accent/10',
      border: 'border-accent/10',
    },
    secondary: {
      gradient: 'from-secondary/15 to-secondary/5',
      iconBg: 'bg-secondary/20',
      text: 'text-secondary',
      glow: 'shadow-secondary/10',
      border: 'border-secondary/10',
    },
    error: {
      gradient: 'from-error/15 to-error/5',
      iconBg: 'bg-error/20',
      text: 'text-error',
      glow: 'shadow-error/10',
      border: 'border-error/10',
    },
  };
  const colors = colorMap[iconColor] || colorMap.accent;

  return (
    <div className={`bg-gradient-to-br ${colors.gradient} rounded-2xl p-6 flex items-center justify-between border ${colors.border} hover:shadow-lg ${colors.glow} transition-all duration-300 group relative overflow-hidden`}>
      {/* Decorative blur circle */}
      <div className={`absolute -top-8 -right-8 w-24 h-24 rounded-full ${colors.iconBg} blur-[40px] opacity-50 pointer-events-none`} />

      <div className="relative z-10">
        <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-text-secondary mb-2">
          {label}
        </p>
        <p className="text-5xl font-black tracking-tight text-text-primary">{value}</p>
        {subtitle && (
          <p className="text-xs text-text-secondary mt-1.5">{subtitle}</p>
        )}
      </div>
      <div className={`w-14 h-14 rounded-2xl ${colors.iconBg} flex items-center justify-center flex-shrink-0 relative z-10 group-hover:scale-110 transition-transform duration-300`}>
        {materialIcon && (
          <span className={`material-symbols-outlined ${colors.text}`} style={{ fontSize: '24px' }}>
            {materialIcon}
          </span>
        )}
      </div>
    </div>
  );
}
