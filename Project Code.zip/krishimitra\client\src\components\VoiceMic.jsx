export default function VoiceMic({ isListening, onStart, onStop, disabled }) {
  return (
    <button
      type="button"
      onClick={isListening ? onStop : onStart}
      disabled={disabled}
      className={`relative w-11 h-11 rounded-full flex items-center justify-center transition-all duration-300 ${
        disabled
          ? 'opacity-40 cursor-not-allowed bg-surface-elevated'
          : isListening
          ? 'bg-error shadow-lg shadow-error/30 hover:shadow-error/40'
          : 'bg-surface-elevated hover:bg-surface-hover active:scale-95'
      }`}
      aria-label={isListening ? 'Stop listening' : 'Start listening'}
    >
      {/* Animated rings when listening */}
      {isListening && (
        <>
          <span className="absolute inset-0 rounded-full bg-error/25 pulse-ring" />
          <span className="absolute inset-0 rounded-full bg-error/15 pulse-ring" style={{ animationDelay: '0.4s' }} />
          <span className="absolute inset-0 rounded-full bg-error/10 pulse-ring" style={{ animationDelay: '0.8s' }} />
        </>
      )}

      <span className={`material-symbols-outlined text-lg relative z-10 transition-colors ${
        isListening ? 'text-white' : 'text-text-secondary'
      }`}>
        {isListening ? 'stop' : 'mic'}
      </span>
    </button>
  );
}
