const express = require('express');
const db = require('../db');
const authMiddleware = require('../middleware/auth');

const router = express.Router();

const VALID_LANGUAGES = ['en', 'te', 'hi', 'ta', 'kn', 'mr', 'gu', 'pa'];
const VALID_THEMES = ['dark', 'light', 'forest'];

// GET /profile
router.get('/profile', authMiddleware, (req, res) => {
  try {
    const profile = db.prepare(`
      SELECT u.id, u.phone, u.language, u.theme, u.created_at,
             COUNT(s.id) as scanCount
      FROM users u
      LEFT JOIN soil_analyses s ON s.user_id = u.id
      WHERE u.id = ?
      GROUP BY u.id
    `).get(req.user.id);

    res.json({ success: true, data: { user: profile } });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to fetch profile' });
  }
});

// PUT /profile
router.put('/profile', authMiddleware, (req, res) => {
  try {
    const { language, theme } = req.body;

    if (language && !VALID_LANGUAGES.includes(language)) {
      return res.status(400).json({ success: false, error: `Invalid language. Must be one of: ${VALID_LANGUAGES.join(', ')}` });
    }

    if (theme && !VALID_THEMES.includes(theme)) {
      return res.status(400).json({ success: false, error: `Invalid theme. Must be one of: ${VALID_THEMES.join(', ')}` });
    }

    if (language) {
      db.prepare('UPDATE users SET language = ? WHERE id = ?').run(language, req.user.id);
    }

    if (theme) {
      db.prepare('UPDATE users SET theme = ? WHERE id = ?').run(theme, req.user.id);
    }

    const user = db.prepare('SELECT id, phone, language, theme, created_at FROM users WHERE id = ?').get(req.user.id);

    res.json({ success: true, data: { user } });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to update profile' });
  }
});

module.exports = router;
