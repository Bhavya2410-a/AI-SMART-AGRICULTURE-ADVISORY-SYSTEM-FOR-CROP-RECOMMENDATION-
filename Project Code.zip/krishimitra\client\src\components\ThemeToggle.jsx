import { useTheme } from '../context/ThemeContext';
import themes from '../themes';

export default function ThemeToggle() {
  const { theme, setTheme } = useTheme();

  return (
    <div className="flex items-center gap-1.5">
      {themes.map((t) => (
        <button
          key={t.id}
          onClick={() => setTheme(t.id)}
          title={t.name}
          className={`w-5 h-5 rounded-full transition-all duration-200 ${
            theme === t.id
              ? 'ring-2 ring-accent ring-offset-1 ring-offset-surface scale-110'
              : 'hover:scale-105 opacity-60 hover:opacity-100'
          }`}
          style={{ backgroundColor: t.dotColor }}
          aria-label={`Switch to ${t.name} theme`}
        />
      ))}
    </div>
  );
}
