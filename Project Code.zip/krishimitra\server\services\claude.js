const Anthropic = require('@anthropic-ai/sdk');

const client = new Anthropic.default({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

const MODEL = 'claude-sonnet-4-20250514';

async function withRetry(fn, maxRetries = 3) {
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      if (error.status === 529 && attempt < maxRetries) {
        const delay = Math.pow(2, attempt) * 1000;
        await new Promise(resolve => setTimeout(resolve, delay));
        continue;
      }
      throw error;
    }
  }
}

async function analyzeSoil(base64Image) {
  const mediaType = base64Image.startsWith('/9j') ? 'image/jpeg'
    : base64Image.startsWith('iVBOR') ? 'image/png'
    : base64Image.startsWith('UklGR') ? 'image/webp'
    : 'image/jpeg';

  const response = await withRetry(() =>
    client.messages.create({
      model: MODEL,
      max_tokens: 1024,
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'image',
              source: {
                type: 'base64',
                media_type: mediaType,
                data: base64Image,
              },
            },
            {
              type: 'text',
              text: `You are an expert Indian agricultural soil scientist. Analyze the uploaded soil image and return a JSON object with exactly these fields:
{
  "soil_type": string (one of: Alluvial, Black/Regur, Red & Yellow, Laterite, Arid/Desert, Mountain/Forest, Peaty/Marshy, Saline/Alkaline),
  "soil_condition": string (Good/Moderate/Poor),
  "ph_estimate": string (e.g. "6.5–7.0"),
  "moisture": string (Dry/Moist/Wet),
  "organic_matter": string (Low/Medium/High),
  "irrigation_recommendation": string (2 sentences),
  "weather_suitability": string (1 sentence based on current season),
  "top_crops": [
    {"name": string, "emoji": string, "confidence": string (e.g. "92%")},
    {"name": string, "emoji": string, "confidence": string},
    {"name": string, "emoji": string, "confidence": string}
  ],
  "summary": string (3 sentence expert summary for a farmer)
}
Return only valid JSON, no markdown, no explanation.`,
            },
          ],
        },
      ],
    })
  );

  const text = response.content[0].text;
  return JSON.parse(text);
}

async function voiceQuery(text, language, conversationHistory) {
  const langNames = {
    'en-US': 'English', 'en-IN': 'English',
    'te-IN': 'Telugu', 'hi-IN': 'Hindi',
  };
  const langName = langNames[language] || 'English';

  // Build messages array: use conversation history if provided, otherwise single message
  const messages = Array.isArray(conversationHistory) && conversationHistory.length > 0
    ? conversationHistory.map(m => ({ role: m.role, content: m.content }))
    : [{ role: 'user', content: text }];

  const response = await withRetry(() =>
    client.messages.create({
      model: MODEL,
      max_tokens: 512,
      system: `You are KrishiMitra, a trusted agricultural advisor who speaks to Indian farmers like a knowledgeable friend — warm, direct, and practical.

Respond in ${langName}.

Your expertise covers soil health, crop selection, pest management, irrigation, organic farming, and seasonal planning across Indian agriculture — Kharif, Rabi, and Zaid seasons, regional soil types, local crop varieties, and government resources like KVK centers and PM-KISAN.

Response rules:
- Keep it conversational — 3 to 5 sentences for simple questions. Go longer only when the farmer's question genuinely needs detail.
- Never use markdown headers (no # or ##). Never use bold (**) for emphasis.
- Use bullet points only when listing 4 or more distinct items (crops, steps, symptoms). For fewer items, weave them into natural sentences.
- Always prefer organic, low-cost, and locally available solutions first. Mention chemical alternatives only when asked or when the situation is urgent.
- Ground advice in the current Indian agricultural season when relevant. Reference local institutions (KVK, agricultural universities, FPOs) when the farmer would benefit from in-person help.
- If you are unsure or the question is outside agriculture, say so honestly rather than guessing.`,
      messages,
    })
  );

  return response.content[0].text;
}

async function analyzeLeafNPK(base64Image, language) {
  const mediaType = base64Image.startsWith('/9j') ? 'image/jpeg'
    : base64Image.startsWith('iVBOR') ? 'image/png'
    : base64Image.startsWith('UklGR') ? 'image/webp'
    : 'image/jpeg';

  const langNames = {
    en: 'English', te: 'Telugu', hi: 'Hindi', ta: 'Tamil',
    kn: 'Kannada', mr: 'Marathi', gu: 'Gujarati', pa: 'Punjabi',
  };
  const langName = langNames[language] || 'English';

  const response = await withRetry(() =>
    client.messages.create({
      model: MODEL,
      max_tokens: 1500,
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'image',
              source: {
                type: 'base64',
                media_type: mediaType,
                data: base64Image,
              },
            },
            {
              type: 'text',
              text: `You are a senior plant pathologist at an Indian agricultural university with 20 years of field experience diagnosing crop nutrient disorders across Kharif, Rabi, and Zaid seasons.

Analyze this leaf image. Your task: determine the Nitrogen (N), Phosphorus (P), and Potassium (K) status by examining leaf color, vein patterns, edge condition, and overall morphology.

Diagnostic protocol:
- Nitrogen: Check for chlorosis progression (older leaves yellowing first = deficient; uniformly dark green = sufficient; lush dark soft growth with delayed fruiting = excess)
- Phosphorus: Check for anthocyanin accumulation (purple/reddish tint on undersides or older leaves = deficient; healthy deep green = sufficient; interveinal chlorosis from induced zinc/iron lockout = excess)
- Potassium: Check leaf margins (brown scorching/necrosis at edges and tips = deficient; firm healthy margins = sufficient; calcium/magnesium antagonism symptoms = excess)
- Also examine: spots, lesions, curling, wilting, vein coloring, interveinal patterns, and any pest/disease signs that may mimic nutrient issues

Respond entirely in ${langName}. All string values in the JSON must be in ${langName}.

Return a JSON object with exactly these fields:
{
  "overall_health": string ("Healthy" / "Mild Deficiency" / "Moderate Deficiency" / "Severe Deficiency"),
  "nitrogen": {
    "status": string ("Deficient" / "Sufficient" / "Excess"),
    "confidence": string (e.g. "85%"),
    "observations": string (2-3 sentences: describe exactly what you see in the leaf color that indicates this nitrogen status — be specific about which part of the leaf, the shade, and the pattern)
  },
  "phosphorus": {
    "status": string ("Deficient" / "Sufficient" / "Excess"),
    "confidence": string,
    "observations": string (2-3 sentences: describe purple/reddish tints, undersides, or healthy coloring you observe)
  },
  "potassium": {
    "status": string ("Deficient" / "Sufficient" / "Excess"),
    "confidence": string,
    "observations": string (2-3 sentences: describe leaf edge condition — scorching, browning, curling, or healthy margins)
  },
  "leaf_color_analysis": string (4-5 sentences describing the complete visual profile: overall hue, color gradients from tip to base, vein vs interveinal contrast, edge condition, any spots or lesions, and what these patterns reveal about plant health),
  "identified_issues": [string] (3-5 specific diagnostic findings, e.g. "Interveinal chlorosis on older leaves with green veins retained — classic nitrogen deficiency pattern"),
  "recommendations": [string] (4-6 actionable remedies — lead with organic/low-cost solutions like vermicompost, jeevamrutha, neem cake; include specific application rates where possible; mention chemical fertilizers as secondary options with dosage),
  "crop_detected": string (identify the crop species if possible — e.g. "Tomato (Solanum lycopersicum)" or "Unknown"),
  "summary": string (4-5 sentence expert assessment written like a trusted agronomist speaking to a farmer — warm, practical, specific to what you observed, with clear next steps)
}

Return only valid JSON. No markdown wrapping. No explanation outside the JSON.`,
            },
          ],
        },
      ],
    })
  );

  const text = response.content[0].text;
  return JSON.parse(text);
}

module.exports = { analyzeSoil, voiceQuery, analyzeLeafNPK };
