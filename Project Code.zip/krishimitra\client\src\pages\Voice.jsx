import { useState, useRef, useEffect, useCallback } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { apiFetch } from '../lib/api';
import VoiceMic from '../components/VoiceMic';
import ChatBubble from '../components/ChatBubble';

const SPEECH_LANGUAGES = [
  { code: 'en-US', label: 'English' },
  { code: 'te-IN', label: 'తెలుగు' },
  { code: 'hi-IN', label: 'हिन्दी' },
];

const WELCOME_MSG = {
  role: 'assistant',
  text: "Hello! I'm KrishiMitra, your farming assistant. Ask me anything about soil, crops, or farming practices.",
  timestamp: Date.now(),
};

const SUGGESTED_QUESTIONS = [
  { icon: 'landscape', text: 'What soil is best for rice?' },
  { icon: 'bug_report', text: 'How to control pests in wheat?' },
  { icon: 'water_drop', text: 'Best irrigation methods?' },
  { icon: 'eco', text: 'Organic farming tips' },
];

const SpeechRecognition =
  typeof window !== 'undefined'
    ? window.SpeechRecognition || window.webkitSpeechRecognition
    : null;

export default function Voice() {
  const { t } = useLanguage();

  const [messages, setMessages] = useState([{ ...WELCOME_MSG }]);
  const [input, setInput] = useState('');
  const [speechLang, setSpeechLang] = useState('en-US');
  const [isListening, setIsListening] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [liveTranscript, setLiveTranscript] = useState('');

  // Session management
  const [sessionId, setSessionId] = useState(null);
  const [sessions, setSessions] = useState([]);
  const [showSessions, setShowSessions] = useState(false);
  const [sessionsLoading, setSessionsLoading] = useState(false);
  const [sessionDirty, setSessionDirty] = useState(false);

  const chatEndRef = useRef(null);
  const recognitionRef = useRef(null);
  const transcriptRef = useRef('');
  const isListeningRef = useRef(false);

  // Auto-scroll on new messages
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isSending]);

  // Build Anthropic-format conversation history from messages (exclude welcome)
  const buildConversationHistory = useCallback((msgs, newUserText) => {
    const history = [];
    for (const m of msgs) {
      if (m.role === 'user') {
        history.push({ role: 'user', content: m.text });
      } else if (m.role === 'assistant' && m !== msgs[0]) {
        history.push({ role: 'assistant', content: m.text });
      }
    }
    history.push({ role: 'user', content: newUserText });
    return history;
  }, []);

  // Save session to server
  const saveSession = useCallback(async (currentMessages, currentSessionId) => {
    const hasUserMessages = currentMessages.some(m => m.role === 'user');
    if (!hasUserMessages) return currentSessionId;
    try {
      const data = await apiFetch('/voice/session/save', {
        method: 'POST',
        body: { sessionId: currentSessionId, messages: currentMessages },
      });
      return data.id;
    } catch (err) {
      console.error('Failed to save session:', err);
      return currentSessionId;
    }
  }, []);

  // Load sessions list
  const loadSessions = useCallback(async () => {
    setSessionsLoading(true);
    try {
      const data = await apiFetch('/voice/sessions');
      setSessions(data.sessions || []);
    } catch {
      setSessions([]);
    } finally {
      setSessionsLoading(false);
    }
  }, []);

  // Load a specific session
  const loadSession = useCallback(async (id) => {
    try {
      const data = await apiFetch(`/voice/session/${id}`);
      setMessages(data.messages || [{ ...WELCOME_MSG }]);
      setSessionId(id);
      setSessionDirty(false);
      setShowSessions(false);
    } catch (err) {
      console.error('Failed to load session:', err);
    }
  }, []);

  // Start new chat (save current if dirty)
  const startNewChat = useCallback(async () => {
    if (sessionDirty) {
      await saveSession(messages, sessionId);
    }
    setSessionId(null);
    setMessages([{ ...WELCOME_MSG, timestamp: Date.now() }]);
    setSessionDirty(false);
    setInput('');
    setShowSessions(false);
  }, [sessionDirty, messages, sessionId, saveSession]);

  // Auto-save when navigating away
  useEffect(() => {
    const handleBeforeUnload = () => {
      if (sessionDirty && messages.some(m => m.role === 'user')) {
        const body = JSON.stringify({ sessionId, messages });
        const session = JSON.parse(localStorage.getItem('krishimitra_session') || 'null');
        if (session?.token) {
          navigator.sendBeacon('/api/voice/session/save',
            new Blob([body], { type: 'application/json' })
          );
        }
      }
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [sessionDirty, messages, sessionId]);

  // Send message with conversation history
  const doSend = useCallback(
    async (text) => {
      const trimmed = text.trim();
      if (!trimmed || isSending) return;

      const userMsg = { role: 'user', text: trimmed, timestamp: Date.now() };
      const updatedMessages = [...messages, userMsg];
      setMessages(updatedMessages);
      setInput('');
      setLiveTranscript('');
      setIsSending(true);
      setSessionDirty(true);

      try {
        const conversationHistory = buildConversationHistory(messages, trimmed);
        const data = await apiFetch('/voice/query', {
          method: 'POST',
          body: { text: trimmed, language: speechLang, messages: conversationHistory },
        });

        const assistantMsg = {
          role: 'assistant',
          text: data.response || 'No response received.',
          timestamp: Date.now(),
        };
        const finalMessages = [...updatedMessages, assistantMsg];
        setMessages(finalMessages);

        const newId = await saveSession(finalMessages, sessionId);
        if (newId && !sessionId) setSessionId(newId);
      } catch (err) {
        const errorMsg = {
          role: 'assistant',
          text: `Sorry, I couldn't process that. ${err.message || 'Please try again.'}`,
          timestamp: Date.now(),
        };
        setMessages(prev => [...prev, errorMsg]);
      } finally {
        setIsSending(false);
      }
    },
    [speechLang, isSending, messages, buildConversationHistory, saveSession, sessionId]
  );

  // Speech recognition
  const startListening = useCallback(() => {
    if (!SpeechRecognition) return;
    if (recognitionRef.current) {
      try { recognitionRef.current.abort(); } catch {}
    }
    transcriptRef.current = '';
    setLiveTranscript('');

    const recognition = new SpeechRecognition();
    recognition.lang = speechLang;
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;

    recognition.onresult = (event) => {
      let transcript = '';
      for (let i = 0; i < event.results.length; i++) {
        transcript += event.results[i][0].transcript;
      }
      transcriptRef.current = transcript;
      setLiveTranscript(transcript);
      setInput(transcript);
    };

    recognition.onerror = (event) => {
      if (event.error === 'network') {
        setIsListening(false);
        isListeningRef.current = false;
        setLiveTranscript('');
        setMessages(prev => [...prev, {
          role: 'assistant',
          text: 'Voice recognition is not available. Your browser may be blocking it. Please type your question instead.',
          timestamp: Date.now(),
        }]);
      } else if (event.error === 'not-allowed') {
        setIsListening(false);
        isListeningRef.current = false;
        setLiveTranscript('');
        setMessages(prev => [...prev, {
          role: 'assistant',
          text: 'Microphone access denied. Please allow microphone access in your browser settings.',
          timestamp: Date.now(),
        }]);
      } else if (event.error !== 'aborted' && event.error !== 'no-speech') {
        setIsListening(false);
        isListeningRef.current = false;
        setLiveTranscript('');
      }
    };

    recognition.onend = () => {
      if (isListeningRef.current) {
        try { recognition.start(); } catch {
          setIsListening(false);
          isListeningRef.current = false;
          setLiveTranscript('');
        }
      }
    };

    recognitionRef.current = recognition;
    try {
      recognition.start();
      setIsListening(true);
      isListeningRef.current = true;
    } catch {}
  }, [speechLang]);

  const stopListening = useCallback(() => {
    isListeningRef.current = false;
    if (recognitionRef.current) {
      try { recognitionRef.current.stop(); } catch {}
    }
    setIsListening(false);
    setLiveTranscript('');
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    doSend(input);
  };

  const handleSuggestionClick = (text) => {
    doSend(text);
  };

  const displayText = isListening && liveTranscript ? liveTranscript : input;
  const hasUserMessages = messages.some(m => m.role === 'user');

  return (
    <div className="flex flex-col" style={{ height: 'calc(100vh - 4rem)' }}>
      {/* ===== HEADER ===== */}
      <div className="shrink-0 ghost-border border-t-0 border-l-0 border-r-0 bg-surface-card">
        <div className="flex items-center justify-between px-5 py-3">
          {/* Left: Bot identity */}
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-11 h-11 rounded-full bg-gradient-to-br from-accent/25 to-accent/10 flex items-center justify-center shadow-sm">
                <span className="material-symbols-outlined text-accent" style={{ fontSize: '22px' }}>eco</span>
              </div>
              <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-green-500 border-2 border-surface-card" />
            </div>
            <div>
              <h1 className="text-[15px] font-bold text-text-primary leading-tight">{t('voice.title')}</h1>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="w-1.5 h-1.5 rounded-full bg-green-500" />
                <p className="text-[10px] font-semibold uppercase tracking-[0.12em] text-green-500">Online</p>
              </div>
            </div>
          </div>

          {/* Right: Actions */}
          <div className="flex items-center gap-2">
            <button
              onClick={startNewChat}
              className="h-9 px-4 rounded-full bg-accent text-accent-on text-xs font-bold hover:brightness-110 active:scale-[0.97] transition-all flex items-center gap-1.5 shadow-sm shadow-accent/15"
            >
              <span className="material-symbols-outlined" style={{ fontSize: '16px' }}>add</span>
              New Chat
            </button>
            <button
              onClick={() => { setShowSessions(!showSessions); if (!showSessions) loadSessions(); }}
              className={`h-9 px-4 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 ${
                showSessions
                  ? 'bg-accent/10 text-accent border border-accent/20'
                  : 'ghost-border text-text-secondary hover:bg-surface-hover hover:text-text-primary'
              }`}
            >
              <span className="material-symbols-outlined" style={{ fontSize: '16px' }}>history</span>
              History
            </button>
          </div>
        </div>
      </div>

      {/* ===== MAIN CONTENT ===== */}
      <div className="flex flex-1 min-h-0">

        {/* ===== SESSIONS SIDEBAR ===== */}
        {showSessions && (
          <div className="w-80 shrink-0 bg-surface-card ghost-border border-t-0 border-b-0 border-l-0 flex flex-col">
            {/* Sidebar header */}
            <div className="px-5 py-4 ghost-border border-t-0 border-l-0 border-r-0">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-accent" style={{ fontSize: '18px' }}>forum</span>
                  <p className="text-sm font-bold text-text-primary">Chat History</p>
                </div>
                <button
                  onClick={() => setShowSessions(false)}
                  className="w-7 h-7 rounded-lg hover:bg-surface-hover flex items-center justify-center transition-colors"
                >
                  <span className="material-symbols-outlined text-text-secondary" style={{ fontSize: '18px' }}>close</span>
                </button>
              </div>
            </div>

            {/* Session list */}
            <div className="flex-1 overflow-y-auto">
              {sessionsLoading ? (
                <div className="flex flex-col items-center justify-center py-16 gap-3">
                  <div className="w-10 h-10 rounded-full border-2 border-accent/20 border-t-accent animate-spin" />
                  <p className="text-xs text-text-secondary">Loading sessions...</p>
                </div>
              ) : sessions.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 px-6 gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-surface-hover flex items-center justify-center">
                    <span className="material-symbols-outlined text-text-secondary/40" style={{ fontSize: '28px' }}>chat_bubble_outline</span>
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-semibold text-text-primary mb-1">No conversations yet</p>
                    <p className="text-xs text-text-secondary">Your chat history will appear here</p>
                  </div>
                </div>
              ) : (
                <div className="p-2 space-y-0.5">
                  {sessions.map((s) => {
                    const isActive = sessionId === s.id;
                    const dateStr = new Date(s.updated_at).toLocaleDateString(undefined, {
                      month: 'short', day: 'numeric',
                    });
                    const timeStr = new Date(s.updated_at).toLocaleTimeString(undefined, {
                      hour: '2-digit', minute: '2-digit',
                    });

                    return (
                      <button
                        key={s.id}
                        onClick={() => loadSession(s.id)}
                        className={`w-full text-left px-4 py-3.5 rounded-xl transition-all duration-200 group ${
                          isActive
                            ? 'bg-accent/8 border border-accent/15'
                            : 'hover:bg-surface-hover border border-transparent'
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 mt-0.5 ${
                            isActive ? 'bg-accent/15' : 'bg-surface-elevated'
                          }`}>
                            <span className={`material-symbols-outlined ${isActive ? 'text-accent' : 'text-text-secondary/60'}`} style={{ fontSize: '18px' }}>
                              chat
                            </span>
                          </div>
                          <div className="min-w-0 flex-1">
                            <p className={`text-sm truncate leading-snug ${isActive ? 'font-bold text-accent' : 'font-medium text-text-primary'}`}>
                              {s.title}
                            </p>
                            <div className="flex items-center gap-2 mt-1.5">
                              <span className="text-[10px] text-text-secondary/60 font-medium">{dateStr}</span>
                              <span className="w-1 h-1 rounded-full bg-text-secondary/20" />
                              <span className="text-[10px] text-text-secondary/60 font-medium">{timeStr}</span>
                            </div>
                          </div>
                          {isActive && (
                            <span className="w-1.5 h-1.5 rounded-full bg-accent mt-2 shrink-0" />
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ===== CHAT AREA ===== */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Messages */}
          <div className="flex-1 overflow-y-auto min-h-0 chat-wallpaper">
            <div className="max-w-3xl mx-auto px-4 md:px-6 py-6">
              {messages.map((msg, i) => (
                <ChatBubble key={i} message={msg} />
              ))}

              {/* Suggested questions (only when no user messages yet) */}
              {!hasUserMessages && !isSending && (
                <div className="mt-6 mb-4">
                  <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-text-secondary/50 mb-3 text-center">
                    Try asking
                  </p>
                  <div className="grid grid-cols-2 gap-2 max-w-md mx-auto">
                    {SUGGESTED_QUESTIONS.map((q) => (
                      <button
                        key={q.text}
                        onClick={() => handleSuggestionClick(q.text)}
                        className="flex items-center gap-2.5 px-4 py-3 rounded-xl bg-surface-card ghost-border text-left hover:bg-surface-hover hover:border-accent/20 transition-all group"
                      >
                        <span className="material-symbols-outlined text-accent/60 group-hover:text-accent transition-colors" style={{ fontSize: '18px' }}>
                          {q.icon}
                        </span>
                        <span className="text-xs text-text-secondary group-hover:text-text-primary transition-colors leading-snug">
                          {q.text}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Typing indicator */}
              {isSending && (
                <div className="flex justify-start mb-4">
                  <div className="flex items-start gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-accent/20 to-accent/10 flex items-center justify-center shrink-0 mt-0.5 shadow-sm">
                      <span className="material-symbols-outlined text-accent" style={{ fontSize: '16px' }}>eco</span>
                    </div>
                    <div className="bg-surface-elevated rounded-2xl rounded-tl-none px-5 py-3.5 ghost-border shadow-sm">
                      <div className="flex items-center gap-3">
                        <span className="inline-flex gap-1">
                          <span className="w-2 h-2 rounded-full bg-accent/60 animate-bounce" style={{ animationDelay: '0ms' }} />
                          <span className="w-2 h-2 rounded-full bg-accent/60 animate-bounce" style={{ animationDelay: '150ms' }} />
                          <span className="w-2 h-2 rounded-full bg-accent/60 animate-bounce" style={{ animationDelay: '300ms' }} />
                        </span>
                        <span className="text-[10px] text-text-secondary/50 font-medium">Thinking...</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div ref={chatEndRef} />
            </div>
          </div>

          {/* Listening indicator */}
          {isListening && (
            <div className="shrink-0 px-5 py-2.5 bg-error/8 border-t border-error/10">
              <div className="flex items-center gap-3 max-w-3xl mx-auto">
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-error/60" />
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-error" />
                </span>
                <span className="text-error font-bold text-[11px] uppercase tracking-[0.12em]">{t('voice.listening')}</span>
                {liveTranscript && (
                  <span className="text-text-primary italic truncate text-xs flex-1 ml-1">"{liveTranscript}"</span>
                )}
              </div>
            </div>
          )}

          {!SpeechRecognition && (
            <p className="text-xs text-text-secondary px-5 py-1.5 shrink-0 text-center">{t('voice.unsupported')}</p>
          )}

          {/* ===== INPUT BAR ===== */}
          <div className="shrink-0 bg-surface-card ghost-border border-b-0 border-l-0 border-r-0">
            <form
              onSubmit={handleSubmit}
              className="max-w-3xl mx-auto flex items-center gap-2 px-4 py-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))] md:pb-3"
            >
              {/* Language selector */}
              <select
                value={speechLang}
                onChange={(e) => setSpeechLang(e.target.value)}
                className="bg-surface-elevated text-text-primary text-xs rounded-xl px-3 py-2.5 ghost-border focus:outline-none focus:ring-2 focus:ring-accent/20 transition-all appearance-none cursor-pointer hover:bg-surface-hover"
              >
                {SPEECH_LANGUAGES.map((l) => (
                  <option key={l.code} value={l.code}>{l.label}</option>
                ))}
              </select>

              {/* Text input */}
              <div className="flex-1 min-w-0 relative">
                <input
                  type="text"
                  value={displayText}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder={isListening ? t('voice.listening') : t('voice.placeholder')}
                  className={`w-full bg-surface-elevated text-text-primary rounded-2xl px-5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-accent/20 placeholder:text-text-secondary/50 transition-all ${
                    isListening ? 'border border-error/30 bg-error/5' : 'ghost-border'
                  }`}
                  disabled={isListening}
                />
              </div>

              {/* Voice mic */}
              {SpeechRecognition && (
                <VoiceMic
                  isListening={isListening}
                  onStart={startListening}
                  onStop={stopListening}
                  disabled={isSending}
                />
              )}

              {/* Send button */}
              <button
                type="submit"
                disabled={!displayText.trim() || isSending || isListening}
                className="w-11 h-11 shrink-0 rounded-full bg-accent flex items-center justify-center disabled:opacity-30 disabled:cursor-not-allowed hover:brightness-110 active:scale-[0.95] transition-all shadow-md shadow-accent/20"
                aria-label={t('voice.send')}
              >
                <span className="material-symbols-outlined text-accent-on" style={{ fontSize: '20px' }}>send</span>
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
