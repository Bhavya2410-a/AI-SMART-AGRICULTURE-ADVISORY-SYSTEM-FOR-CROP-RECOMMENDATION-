import { useState, useEffect, useCallback } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { apiFetch } from '../lib/api';

const WMO_MAP = {
  0: { emoji: '\u2600\uFE0F', label: 'Clear', bg: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800&q=80', tip: 'Great day for field work' },
  1: { emoji: '\u26C5', label: 'Partly Cloudy', bg: 'https://images.unsplash.com/photo-1534088568595-a066f410bcda?w=800&q=80', tip: 'Good conditions for sowing' },
  2: { emoji: '\u26C5', label: 'Partly Cloudy', bg: 'https://images.unsplash.com/photo-1534088568595-a066f410bcda?w=800&q=80', tip: 'Good conditions for sowing' },
  3: { emoji: '\u26C5', label: 'Overcast', bg: 'https://images.unsplash.com/photo-1534088568595-a066f410bcda?w=800&q=80', tip: 'Good for transplanting' },
  45: { emoji: '\uD83C\uDF2B\uFE0F', label: 'Fog', bg: 'https://images.unsplash.com/photo-1487621167305-5d248087c724?w=800&q=80', tip: 'Monitor for fungal diseases' },
  48: { emoji: '\uD83C\uDF2B\uFE0F', label: 'Fog', bg: 'https://images.unsplash.com/photo-1487621167305-5d248087c724?w=800&q=80', tip: 'Monitor for fungal diseases' },
  51: { emoji: '\uD83C\uDF26\uFE0F', label: 'Drizzle', bg: 'https://images.unsplash.com/photo-1501691223387-dd0500403074?w=800&q=80', tip: 'Light moisture for seedlings' },
  53: { emoji: '\uD83C\uDF26\uFE0F', label: 'Drizzle', bg: 'https://images.unsplash.com/photo-1501691223387-dd0500403074?w=800&q=80', tip: 'Light moisture for seedlings' },
  55: { emoji: '\uD83C\uDF26\uFE0F', label: 'Drizzle', bg: 'https://images.unsplash.com/photo-1501691223387-dd0500403074?w=800&q=80', tip: 'Light moisture for seedlings' },
  61: { emoji: '\uD83C\uDF27\uFE0F', label: 'Rain', bg: 'https://images.unsplash.com/photo-1501691223387-dd0500403074?w=800&q=80', tip: 'Check drainage channels' },
  63: { emoji: '\uD83C\uDF27\uFE0F', label: 'Rain', bg: 'https://images.unsplash.com/photo-1501691223387-dd0500403074?w=800&q=80', tip: 'Check drainage channels' },
  65: { emoji: '\uD83C\uDF27\uFE0F', label: 'Heavy Rain', bg: 'https://images.unsplash.com/photo-1501691223387-dd0500403074?w=800&q=80', tip: 'Protect crops from waterlogging' },
  71: { emoji: '\u2744\uFE0F', label: 'Snow', bg: 'https://images.unsplash.com/photo-1491002052546-bf38f186af56?w=800&q=80', tip: 'Cover sensitive crops' },
  73: { emoji: '\u2744\uFE0F', label: 'Snow', bg: 'https://images.unsplash.com/photo-1491002052546-bf38f186af56?w=800&q=80', tip: 'Cover sensitive crops' },
  75: { emoji: '\u2744\uFE0F', label: 'Heavy Snow', bg: 'https://images.unsplash.com/photo-1491002052546-bf38f186af56?w=800&q=80', tip: 'Protect orchards from frost' },
  77: { emoji: '\u2744\uFE0F', label: 'Snow Grains', bg: 'https://images.unsplash.com/photo-1491002052546-bf38f186af56?w=800&q=80', tip: 'Cover sensitive crops' },
  80: { emoji: '\uD83C\uDF26\uFE0F', label: 'Showers', bg: 'https://images.unsplash.com/photo-1501691223387-dd0500403074?w=800&q=80', tip: 'Natural irrigation for crops' },
  81: { emoji: '\uD83C\uDF26\uFE0F', label: 'Showers', bg: 'https://images.unsplash.com/photo-1501691223387-dd0500403074?w=800&q=80', tip: 'Natural irrigation for crops' },
  82: { emoji: '\uD83C\uDF26\uFE0F', label: 'Heavy Showers', bg: 'https://images.unsplash.com/photo-1501691223387-dd0500403074?w=800&q=80', tip: 'Ensure proper drainage' },
  95: { emoji: '\u26C8\uFE0F', label: 'Thunderstorm', bg: 'https://images.unsplash.com/photo-1605727216801-e27ce1d0cc28?w=800&q=80', tip: 'Stay indoors, avoid fields' },
  96: { emoji: '\u26C8\uFE0F', label: 'Thunderstorm', bg: 'https://images.unsplash.com/photo-1605727216801-e27ce1d0cc28?w=800&q=80', tip: 'Stay indoors, avoid fields' },
  99: { emoji: '\u26C8\uFE0F', label: 'Thunderstorm', bg: 'https://images.unsplash.com/photo-1605727216801-e27ce1d0cc28?w=800&q=80', tip: 'Stay indoors, avoid fields' },
};

function getWeatherInfo(code) {
  if (WMO_MAP[code]) return WMO_MAP[code];
  if (code >= 1 && code <= 3) return WMO_MAP[1];
  if (code >= 45 && code <= 48) return WMO_MAP[45];
  if (code >= 51 && code <= 55) return WMO_MAP[51];
  if (code >= 61 && code <= 65) return WMO_MAP[61];
  if (code >= 71 && code <= 77) return WMO_MAP[71];
  if (code >= 80 && code <= 82) return WMO_MAP[80];
  if (code >= 95 && code <= 99) return WMO_MAP[95];
  return { emoji: '\uD83C\uDF24\uFE0F', label: 'Unknown', bg: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800&q=80', tip: 'Check conditions before field work' };
}

function getDayName(dateStr) {
  const date = new Date(dateStr + 'T00:00:00');
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);

  if (date.getTime() === today.getTime()) return 'Today';
  if (date.getTime() === tomorrow.getTime()) return 'Tomorrow';
  return date.toLocaleDateString(undefined, { weekday: 'short' });
}

export default function WeatherWidget() {
  const { t } = useLanguage();
  const [weather, setWeather] = useState(null);
  const [city, setCity] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const fetchWeather = useCallback(async () => {
    setLoading(true);
    setError(false);
    try {
      const location = await apiFetch('/weather/location');
      const { lat, lon, city: cityName } = location;
      setCity(cityName || 'Your Location');

      const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min,weather_code&timezone=auto&forecast_days=3`;
      const res = await fetch(url);
      if (!res.ok) throw new Error(`Weather fetch failed: ${res.status}`);
      const data = await res.json();
      setWeather(data);
    } catch (err) {
      console.error('WeatherWidget fetch error:', err);
      setError(true);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchWeather();
  }, [fetchWeather]);

  if (loading) {
    return (
      <div className="bg-surface-card ghost-border rounded-2xl p-8 animate-pulse">
        <div className="h-5 bg-surface-hover rounded w-1/3 mb-6" />
        <div className="flex items-center gap-6 mb-8">
          <div className="h-20 w-20 bg-surface-hover rounded-2xl" />
          <div>
            <div className="h-14 bg-surface-hover rounded w-32 mb-3" />
            <div className="h-4 bg-surface-hover rounded w-24" />
          </div>
        </div>
        <div className="grid grid-cols-3 gap-4">
          <div className="h-28 bg-surface-hover rounded-xl" />
          <div className="h-28 bg-surface-hover rounded-xl" />
          <div className="h-28 bg-surface-hover rounded-xl" />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-surface-card ghost-border rounded-2xl p-8 text-center">
        <div className="w-16 h-16 rounded-2xl bg-surface-elevated flex items-center justify-center mx-auto mb-4">
          <span className="material-symbols-outlined text-text-secondary" style={{ fontSize: '28px' }}>cloud_off</span>
        </div>
        <p className="text-text-secondary text-sm mb-4">{t('dashboard.weatherUnavailable')}</p>
        <button onClick={fetchWeather} className="text-accent font-bold text-sm hover:underline uppercase tracking-[0.15em]">
          {t('common.retry')}
        </button>
      </div>
    );
  }

  const current = weather?.current;
  const daily = weather?.daily;
  const currentInfo = getWeatherInfo(current?.weather_code);

  return (
    <div className="rounded-2xl overflow-hidden relative">
      {/* Background image */}
      <img
        src={currentInfo.bg}
        alt=""
        className="absolute inset-0 w-full h-full object-cover"
        loading="lazy"
      />
      <div className="absolute inset-0 bg-gradient-to-br from-black/70 via-black/50 to-black/60 backdrop-blur-[2px]" />

      <div className="relative z-10 p-6 md:p-8">
        {/* Header with location badge */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <h3 className="text-[10px] font-bold uppercase tracking-[0.15em] text-white/70">
              {t('dashboard.weatherTitle')}
            </h3>
          </div>
          <span className="text-xs text-white/80 bg-white/10 backdrop-blur-md px-3 py-1.5 rounded-full flex items-center gap-1.5 border border-white/10">
            <span className="material-symbols-outlined text-green-400" style={{ fontSize: '14px' }}>location_on</span>
            {city}
          </span>
        </div>

        {/* Current weather */}
        <div className="flex items-center gap-6 mb-6">
          <span className="text-5xl drop-shadow-lg">{currentInfo.emoji}</span>
          <div>
            <p className="text-6xl font-black text-white tracking-tight leading-none drop-shadow-lg">
              {Math.round(current?.temperature_2m ?? 0)}&deg;
            </p>
            <p className="text-sm text-white/70 mt-2 font-medium">{currentInfo.label}</p>
          </div>
          <div className="ml-auto text-right space-y-3">
            <div className="flex items-center gap-2.5 justify-end">
              <span className="material-symbols-outlined text-blue-300/70" style={{ fontSize: '18px' }}>humidity_percentage</span>
              <span className="text-sm text-white/80 font-medium">{current?.relative_humidity_2m}%</span>
            </div>
            <div className="flex items-center gap-2.5 justify-end">
              <span className="material-symbols-outlined text-blue-300/70" style={{ fontSize: '18px' }}>air</span>
              <span className="text-sm text-white/80 font-medium">{Math.round(current?.wind_speed_10m ?? 0)} km/h</span>
            </div>
          </div>
        </div>

        {/* Farming tip */}
        <div className="bg-white/10 backdrop-blur-md rounded-xl px-4 py-3 mb-6 border border-white/10">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-amber-300" style={{ fontSize: '16px' }}>tips_and_updates</span>
            <p className="text-xs text-white/90 font-medium">{currentInfo.tip}</p>
          </div>
        </div>

        {/* Forecast grid */}
        {daily && (
          <div className="grid grid-cols-3 gap-3">
            {daily.time.map((date, i) => {
              const info = getWeatherInfo(daily.weather_code[i]);
              return (
                <div key={date} className="bg-white/10 backdrop-blur-md rounded-xl p-4 text-center border border-white/5 hover:bg-white/15 transition-colors">
                  <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-white/60 mb-3">
                    {getDayName(date)}
                  </p>
                  <p className="text-3xl mb-2 drop-shadow">{info.emoji}</p>
                  <p className="text-sm text-white font-bold">
                    {Math.round(daily.temperature_2m_max[i])}&deg;
                    <span className="text-white/50 font-medium ml-1">
                      / {Math.round(daily.temperature_2m_min[i])}&deg;
                    </span>
                  </p>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
