import { useState, useRef, useCallback } from 'react';
import { useLanguage } from '../context/LanguageContext';

const MAX_SIZE = 10 * 1024 * 1024;
const ACCEPTED_TYPES = ['image/jpeg', 'image/png', 'image/webp'];

export default function ImageUploader({ onImageSelect }) {
  const { t } = useLanguage();
  const [preview, setPreview] = useState(null);
  const [dragActive, setDragActive] = useState(false);
  const [error, setError] = useState('');
  const inputRef = useRef(null);

  const processFile = useCallback(
    (file) => {
      setError('');
      if (!ACCEPTED_TYPES.includes(file.type)) {
        setError('Please select a JPEG, PNG, or WebP image.');
        return;
      }
      if (file.size > MAX_SIZE) {
        setError('Image must be under 10MB.');
        return;
      }
      const reader = new FileReader();
      reader.onload = (e) => {
        const dataUrl = e.target.result;
        setPreview(dataUrl);
        const base64 = dataUrl.split(',')[1];
        onImageSelect(base64);
      };
      reader.readAsDataURL(file);
    },
    [onImageSelect]
  );

  const handleDrop = useCallback(
    (e) => {
      e.preventDefault();
      e.stopPropagation();
      setDragActive(false);
      const file = e.dataTransfer?.files?.[0];
      if (file) processFile(file);
    },
    [processFile]
  );

  const handleDragOver = (e) => { e.preventDefault(); e.stopPropagation(); setDragActive(true); };
  const handleDragLeave = (e) => { e.preventDefault(); e.stopPropagation(); setDragActive(false); };
  const handleChange = (e) => { const file = e.target.files?.[0]; if (file) processFile(file); };

  const handleRemove = () => {
    setPreview(null);
    setError('');
    onImageSelect(null);
    if (inputRef.current) inputRef.current.value = '';
  };

  if (preview) {
    return (
      <div className="relative rounded-2xl overflow-hidden ghost-border group">
        <img src={preview} alt="Soil preview" className="w-full max-h-80 object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        <button
          onClick={handleRemove}
          className="absolute top-4 right-4 bg-error/90 backdrop-blur-sm hover:bg-error text-white rounded-full p-2.5 shadow-lg transition-all duration-200 hover:scale-110"
          aria-label="Remove image"
        >
          <span className="material-symbols-outlined text-lg">close</span>
        </button>
        {/* Image info overlay */}
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-white/80 text-sm">check_circle</span>
            <span className="text-xs text-white/80 font-medium">Image ready for analysis</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div
        role="button"
        tabIndex={0}
        onClick={() => inputRef.current?.click()}
        onKeyDown={(e) => e.key === 'Enter' && inputRef.current?.click()}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        className={`relative flex flex-col items-center justify-center gap-5 p-10 rounded-2xl border-2 border-dashed transition-all duration-300 cursor-pointer overflow-hidden ${
          dragActive
            ? 'border-accent bg-accent/5 scale-[1.01]'
            : 'border-text-secondary/20 bg-surface-lowest hover:bg-surface-hover hover:border-accent/30'
        }`}
      >
        {/* Subtle background texture */}
        <div className="absolute inset-0 opacity-[0.04] pointer-events-none">
          <img
            src="https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=400&q=20"
            alt=""
            className="w-full h-full object-cover"
          />
        </div>

        <div className="relative z-10 flex flex-col items-center gap-5">
          <div className="w-20 h-20 rounded-2xl bg-accent/10 flex items-center justify-center">
            <span className="material-symbols-outlined text-accent" style={{ fontSize: '36px' }}>photo_camera</span>
          </div>

          <div className="text-center space-y-1.5">
            <p className="text-text-primary font-bold text-lg">{t('soil.upload')}</p>
            <p className="text-text-secondary text-sm">{t('soil.uploadHint')}</p>
            <p className="text-text-secondary/50 text-xs mt-2">JPEG, PNG, WebP up to 10MB</p>
          </div>
        </div>
      </div>

      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        capture="environment"
        onChange={handleChange}
        className="hidden"
      />

      {error && (
        <div className="flex items-center gap-2 justify-center mt-3 p-3 rounded-xl bg-error/5 border border-error/10">
          <span className="material-symbols-outlined text-error text-sm">error</span>
          <p className="text-error text-sm font-medium">{error}</p>
        </div>
      )}
    </div>
  );
}
