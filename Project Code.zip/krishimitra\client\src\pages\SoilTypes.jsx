import { useLanguage } from '../context/LanguageContext';
import soilTypesData from '../data/soilTypesData';
import SoilTypeCard from '../components/SoilTypeCard';

export default function SoilTypes() {
  const { t } = useLanguage();

  return (
    <div className="py-8">
      {/* Hero Banner */}
      <div className="relative rounded-2xl overflow-hidden mb-8">
        <img
          src="https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=1200&q=80"
          alt="Indian farmland"
          className="w-full h-48 md:h-64 object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/40 to-transparent" />
        <div className="absolute inset-0 flex flex-col justify-center px-6 md:px-10">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-green-300">
              Indian Soil Classification
            </span>
          </div>
          <h1 className="text-2xl md:text-4xl font-black tracking-tight text-white drop-shadow-lg mb-3">
            {t('soilTypes.title')}
          </h1>
          <p className="text-sm text-white/70 max-w-lg leading-relaxed hidden md:block">
            India's vast geography spans 8 major soil types, each shaped by climate, terrain, and centuries of geological processes.
          </p>
        </div>
      </div>

      {/* Soil diversity info bar */}
      <div className="bg-surface-card ghost-border rounded-2xl p-5 mb-8 flex flex-col sm:flex-row items-start sm:items-center gap-4">
        <div className="flex items-center gap-3 flex-1">
          <div className="w-10 h-10 rounded-xl bg-accent/15 flex items-center justify-center shrink-0">
            <span className="material-symbols-outlined text-accent" style={{ fontSize: '20px' }}>landscape</span>
          </div>
          <p className="text-sm text-text-secondary leading-relaxed">
            Understanding your soil type is the first step toward optimal crop selection, nutrient management, and sustainable farming.
          </p>
        </div>
        {/* Color spectrum */}
        <div className="flex items-center gap-1 shrink-0">
          {soilTypesData.map((soil) => (
            <div
              key={soil.id}
              className="w-6 h-6 rounded-lg transition-transform hover:scale-125 cursor-pointer"
              style={{ backgroundColor: soil.color }}
              title={soil.name}
            />
          ))}
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {soilTypesData.map((soil) => (
          <SoilTypeCard key={soil.id} soil={soil} />
        ))}
      </div>
    </div>
  );
}
