const express = require('express');

const router = express.Router();

// GET /location
router.get('/location', async (req, res) => {
  try {
    console.log('[Weather] Fetching location from ip-api.com...');
    const response = await fetch('http://ip-api.com/json/');
    const data = await response.json();
    console.log('[Weather] ip-api response:', JSON.stringify(data).slice(0, 200));

    if (data.status === 'fail') {
      console.error('[Weather] ip-api returned fail:', data.message);
      return res.status(500).json({ success: false, error: 'Failed to determine location' });
    }

    res.json({
      success: true,
      data: {
        lat: data.lat,
        lon: data.lon,
        city: data.city,
        region: data.regionName,
        country: data.country,
      },
    });
  } catch (error) {
    console.error('[Weather] Location fetch error:', error.message);
    res.status(500).json({ success: false, error: 'Failed to fetch location data' });
  }
});

module.exports = router;
