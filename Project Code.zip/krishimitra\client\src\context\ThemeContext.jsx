import { createContext, useContext, useState, useEffect } from 'react';
import { apiFetch } from '../lib/api';

const ThemeContext = createContext(null);

export function ThemeProvider({ children }) {
  const [theme, setThemeState] = useState(() => {
    const stored = localStorage.getItem('krishimitra_theme');
    if (stored) return stored;
    try {
      const session = JSON.parse(localStorage.getItem('krishimitra_session') || 'null');
      return session?.user?.theme || 'dark';
    } catch {
      return 'dark';
    }
  });

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  const setTheme = (newTheme) => {
    setThemeState(newTheme);
    localStorage.setItem('krishimitra_theme', newTheme);
    document.documentElement.setAttribute('data-theme', newTheme);

    const session = localStorage.getItem('krishimitra_session');
    if (session) {
      apiFetch('/user/profile', {
        method: 'PUT',
        body: { theme: newTheme },
      }).catch(() => {});
    }
  };

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used within ThemeProvider');
  return ctx;
}
