/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      colors: {
        surface: {
          DEFAULT: 'var(--bg-primary)',
          card: 'var(--bg-card)',
          hover: 'var(--bg-card-hover)',
          elevated: 'var(--bg-elevated)',
          highest: 'var(--bg-highest)',
          bright: 'var(--bg-bright)',
          lowest: 'var(--bg-lowest)',
        },
        accent: {
          DEFAULT: 'var(--accent)',
          container: 'var(--accent-container)',
          hover: 'var(--accent-hover)',
          on: 'var(--accent-on)',
        },
        secondary: {
          DEFAULT: 'var(--secondary)',
          container: 'var(--secondary-container)',
        },
        tertiary: {
          DEFAULT: 'var(--tertiary)',
          container: 'var(--tertiary-container)',
        },
        error: {
          DEFAULT: 'var(--error)',
          container: 'var(--error-container)',
        },
        text: {
          primary: 'var(--text-primary)',
          secondary: 'var(--text-secondary)',
          'on-accent': 'var(--text-on-accent)',
        },
        outline: {
          DEFAULT: 'var(--outline)',
          variant: 'var(--outline-variant)',
        },
        border: {
          DEFAULT: 'var(--border)',
          subtle: 'var(--border-subtle)',
        },
      },
    },
  },
  plugins: [],
};
