const faqData = [
  {
    question: 'How does soil analysis work?',
    answer:
      'Simply take a photo of your soil and upload it. Our AI analyzes the image to identify soil type, condition, and provides crop recommendations tailored to your region.',
  },
  {
    question: 'What image quality is needed?',
    answer:
      'For best results, take a clear photo in natural daylight. Ensure the soil fills most of the frame. Avoid shadows and blur. Both camera capture and gallery upload are supported.',
  },
  {
    question: 'Which languages are supported?',
    answer:
      'KrishiMitra supports 8 languages: English, Telugu, Hindi, Tamil, Kannada, Marathi, Gujarati, and Punjabi. You can change your language from the Profile page.',
  },
  {
    question: 'Is my data private?',
    answer:
      'Yes, your soil analysis data is stored securely and only accessible to you. We do not share your data with third parties.',
  },
  {
    question: 'How accurate is the AI analysis?',
    answer:
      'Our AI provides estimated analysis based on visual inspection. For precise measurements, we recommend laboratory soil testing. The AI is best used as a preliminary guide.',
  },
];

export default faqData;
