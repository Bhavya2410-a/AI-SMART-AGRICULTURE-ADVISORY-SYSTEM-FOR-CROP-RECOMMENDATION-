import { createContext, useContext, useState, useCallback } from 'react';
import translations from '../translations';

const LanguageContext = createContext(null);

function getNestedValue(obj, path) {
  return path.split('.').reduce((acc, key) => acc?.[key], obj);
}

export function LanguageProvider({ children }) {
  const [language, setLanguageState] = useState(() => {
    const stored = localStorage.getItem('krishimitra_language');
    if (stored) return stored;
    try {
      const session = JSON.parse(localStorage.getItem('krishimitra_session') || 'null');
      return session?.user?.language || 'en';
    } catch {
      return 'en';
    }
  });

  const t = useCallback(
    (key) => {
      const value = getNestedValue(translations[language], key);
      if (value !== undefined) return value;
      const fallback = getNestedValue(translations.en, key);
      if (fallback !== undefined) return fallback;
      return key;
    },
    [language]
  );

  const setLanguage = (lang) => {
    setLanguageState(lang);
    localStorage.setItem('krishimitra_language', lang);
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error('useLanguage must be used within LanguageProvider');
  return ctx;
}
