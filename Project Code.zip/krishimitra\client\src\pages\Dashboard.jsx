import { useState, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { apiFetch } from '../lib/api';
import StatCard from '../components/StatCard';
import WeatherWidget from '../components/WeatherWidget';
import QuickActions from '../components/QuickActions';
import RecentScans from '../components/RecentScans';

function getGreetingKey() {
  const hour = new Date().getHours();
  if (hour < 12) return 'dashboard.goodMorning';
  if (hour < 17) return 'dashboard.goodAfternoon';
  return 'dashboard.goodEvening';
}

function getDaysActive(createdAt) {
  if (!createdAt) return 0;
  const created = new Date(createdAt);
  const now = new Date();
  const diff = Math.floor((now - created) / (1000 * 60 * 60 * 24));
  return Math.max(diff, 1);
}

const FARMING_TIPS = [
  'Healthy soil is the foundation of a productive farm. Test your soil regularly to maintain optimal nutrient levels.',
  'Crop rotation helps prevent soil depletion and reduces pest buildup naturally.',
  'Mulching conserves moisture, regulates soil temperature, and suppresses weeds.',
  'Early morning is the best time to water your crops -- less evaporation, more absorption.',
  'Companion planting can naturally deter pests and improve crop yields.',
];

function getRandomTip() {
  const today = new Date();
  const index = (today.getFullYear() * 366 + today.getMonth() * 31 + today.getDate()) % FARMING_TIPS.length;
  return FARMING_TIPS[index];
}

function FarmScoreDonut({ score }) {
  const radius = 40;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;
  const color = score >= 70 ? '#4be277' : score >= 40 ? '#ffb95f' : '#ffb4ab';

  return (
    <div className="relative w-28 h-28 flex items-center justify-center">
      <svg width="112" height="112" viewBox="0 0 112 112" className="-rotate-90">
        <circle cx="56" cy="56" r={radius} fill="none" stroke="var(--bg-elevated)" strokeWidth="8" />
        <circle
          cx="56" cy="56" r={radius} fill="none"
          stroke={color} strokeWidth="8" strokeLinecap="round"
          strokeDasharray={circumference} strokeDashoffset={offset}
          className="donut-ring"
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-2xl font-black text-text-primary">{score}%</span>
        <span className="text-[9px] font-bold uppercase tracking-widest text-text-secondary">Score</span>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const { t } = useLanguage();
  const { user } = useAuth();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiFetch('/user/profile')
      .then((data) => setProfile(data?.user || data))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const scanCount = profile?.scanCount ?? 0;
  const daysActive = getDaysActive(profile?.created_at || user?.created_at);
  const farmScore = Math.min(100, Math.max(20, scanCount * 15 + daysActive * 2));

  return (
    <div className="py-8 space-y-8">
      {/* Hero Banner */}
      <div className="relative rounded-2xl overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=1200&q=80"
          alt="Farmland at golden hour"
          className="w-full h-48 md:h-56 object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/40 to-transparent" />
        <div className="absolute inset-0 flex flex-col justify-center px-6 md:px-10">
          <h1 className="text-3xl md:text-4xl font-black tracking-tight text-white leading-tight drop-shadow-lg">
            {t(getGreetingKey())} {'\uD83D\uDE4F'}
          </h1>
          <div className="flex items-center gap-2 mt-3">
            <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <p className="text-[11px] font-bold uppercase tracking-[0.15em] text-white/70">
              {t('dashboard.farmerGreeting')}
            </p>
          </div>
        </div>
      </div>

      {/* Stats Row */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-surface-card ghost-border rounded-2xl p-6 animate-pulse">
              <div className="h-3 bg-surface-hover rounded w-1/2 mb-3" />
              <div className="h-12 bg-surface-hover rounded w-1/3" />
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <StatCard
            materialIcon="document_scanner"
            label={t('dashboard.totalScans')}
            value={scanCount}
            iconColor="accent"
            subtitle="Soil analyses completed"
          />
          <StatCard
            materialIcon="calendar_today"
            label={t('dashboard.daysActive')}
            value={daysActive}
            iconColor="secondary"
            subtitle="Days since you joined"
          />
          <StatCard
            materialIcon="trending_up"
            label={t('dashboard.active')}
            value={scanCount}
            iconColor="accent"
            subtitle="Keep scanning for insights"
          />
        </div>
      )}

      {/* Farm Health Overview */}
      {!loading && (
        <div className="bg-surface-card ghost-border rounded-2xl p-6 md:p-8">
          <div className="flex items-center gap-2 mb-6">
            <div className="w-2 h-2 rounded-full bg-accent" />
            <h3 className="text-[10px] font-bold uppercase tracking-[0.15em] text-text-secondary">
              Farm Health Overview
            </h3>
          </div>
          <div className="flex flex-col md:flex-row items-center gap-8">
            {/* Farm Score Donut */}
            <div className="flex flex-col items-center gap-3">
              <FarmScoreDonut score={farmScore} />
              <p className="text-xs text-text-secondary font-medium">Overall Health</p>
            </div>

            {/* Status indicators */}
            <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-4 w-full">
              <div className="bg-surface-lowest rounded-xl p-4 flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-accent/15 flex items-center justify-center shrink-0">
                  <span className="material-symbols-outlined text-accent" style={{ fontSize: '20px' }}>search</span>
                </div>
                <div>
                  <p className="text-sm font-bold text-text-primary">
                    {scanCount > 0 ? `${scanCount} scan${scanCount > 1 ? 's' : ''} done` : 'No scans yet'}
                  </p>
                  <p className="text-[10px] text-text-secondary uppercase tracking-widest mt-0.5">
                    {scanCount > 0 ? 'Soil analyzed' : 'Start your first scan'}
                  </p>
                </div>
              </div>

              <div className="bg-surface-lowest rounded-xl p-4 flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-secondary/15 flex items-center justify-center shrink-0">
                  <span className="material-symbols-outlined text-secondary" style={{ fontSize: '20px' }}>notifications_active</span>
                </div>
                <div>
                  <p className="text-sm font-bold text-text-primary">5 advisories</p>
                  <p className="text-[10px] text-text-secondary uppercase tracking-widest mt-0.5">Available to read</p>
                </div>
              </div>

              <div className="bg-surface-lowest rounded-xl p-4 flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-accent/15 flex items-center justify-center shrink-0">
                  <span className="material-symbols-outlined text-accent" style={{ fontSize: '20px' }}>eco</span>
                </div>
                <div>
                  <p className="text-sm font-bold text-text-primary">NPK Ready</p>
                  <p className="text-[10px] text-text-secondary uppercase tracking-widest mt-0.5">Leaf analyzer active</p>
                </div>
              </div>

              <div className="bg-surface-lowest rounded-xl p-4 flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-tertiary/15 flex items-center justify-center shrink-0">
                  <span className="material-symbols-outlined text-tertiary" style={{ fontSize: '20px' }}>smart_toy</span>
                </div>
                <div>
                  <p className="text-sm font-bold text-text-primary">AI Assistant</p>
                  <p className="text-[10px] text-text-secondary uppercase tracking-widest mt-0.5">Online & ready</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Weather */}
      <WeatherWidget />

      {/* Quick Actions + Recent Scans */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <QuickActions />
        </div>
        <div className="lg:col-span-1">
          <RecentScans />
        </div>
      </div>

      {/* Motivational Tip Card */}
      <div className="relative rounded-2xl overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800&q=80"
          alt="Farming"
          className="w-full h-48 object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/40" />
        <div className="absolute inset-0 flex items-center px-6 md:px-10">
          <div className="flex items-start gap-4 max-w-2xl">
            <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-sm flex items-center justify-center flex-shrink-0 border border-white/10">
              <span className="material-symbols-outlined text-amber-300" style={{ fontSize: '24px' }}>
                lightbulb
              </span>
            </div>
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.15em] text-amber-300 mb-2">
                Daily Farming Tip
              </p>
              <p className="text-sm text-white/90 leading-relaxed">
                {getRandomTip()}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
