# KrishiMitra - Installation & Setup Guide

**AI-Powered Soil & Crop Advisory App for Indian Farmers**

---

## Prerequisites

Before you begin, make sure you have the following installed on your Windows PC:

| Software | Minimum Version | Download Link |
|----------|----------------|---------------|
| **Node.js** | v18.0.0+ | https://nodejs.org/ |
| **npm** | v9.0.0+ | (comes with Node.js) |
| **Git** | (optional) | https://git-scm.com/ |

### Verify installations

Open **Command Prompt** or **PowerShell** and run:

```bash
node --version
npm --version
```

Both commands should print version numbers. If not, install Node.js first.

---

## Project Structure

```
krishimitra/
├── client/          # React frontend (Vite + Tailwind CSS)
├── server/          # Express.js backend (Node.js)
├── .env             # Environment variables (API keys)
├── .env.example     # Template for .env
├── package.json     # Root package (runs both client & server)
└── INSTALLATION_GUIDE.md
```

---

## Step-by-Step Setup

### Step 1: Extract the ZIP

Extract the `krishimitra.zip` file to any folder on your PC, for example:
```
C:\Projects\krishimitra
```

### Step 2: Open Terminal in the Project Folder

Open **Command Prompt** or **PowerShell**, then navigate to the extracted folder:

```bash
cd C:\Projects\krishimitra
```

(Replace `C:\Projects\krishimitra` with your actual path.)

### Step 3: Configure Environment Variables

The `.env` file is already included with a working Anthropic API key. If you need to change it:

1. Open `.env` in any text editor
2. Update the values:

```
ANTHROPIC_API_KEY=your_anthropic_api_key_here
PORT=5000
```

### Step 4: Install All Dependencies

Run these commands one by one:

```bash
npm install
```

```bash
cd server
npm install
cd ..
```

```bash
cd client
npm install
cd ..
```

This installs dependencies for the root, server, and client.

### Step 5: Build the Frontend (Production)

```bash
cd client
npm run build
cd ..
```

This creates optimized files in `client/dist/`.

### Step 6: Start the Application

**Option A - Production mode** (serves both frontend & backend on one port):

```bash
cd server
node index.js
```

Then open your browser at: **http://localhost:5000**

**Option B - Development mode** (hot-reload for both client & server):

First install concurrently at root level if not already:
```bash
npm install
```

Then run:
```bash
npm run dev
```

- Frontend will be at: **http://localhost:5173**
- Backend API at: **http://localhost:5000**

---

## All Commands Reference

| Command | Where to Run | What It Does |
|---------|-------------|--------------|
| `npm install` | `krishimitra/` | Install root dependencies |
| `cd server && npm install` | `krishimitra/` | Install server dependencies |
| `cd client && npm install` | `krishimitra/` | Install client dependencies |
| `cd client && npm run build` | `krishimitra/` | Build frontend for production |
| `cd server && node index.js` | `krishimitra/` | Start server (production) |
| `npm run dev` | `krishimitra/` | Start both client & server (dev) |
| `cd client && npm run dev` | `krishimitra/` | Start only frontend (dev) |
| `cd server && npm run dev` | `krishimitra/` | Start only server with auto-reload |

---

## Features

- **Soil Analysis** - Upload a soil image and get AI-powered analysis (soil type, pH, moisture, crop recommendations)
- **Leaf NPK Analysis** - Upload a leaf image to detect Nitrogen, Phosphorus, and Potassium status
- **Voice Assistant** - Ask farming questions via voice in English, Hindi, or Telugu
- **Seasonal Advisory** - Get region-specific farming advice
- **Soil Types Guide** - Learn about 8 Indian soil types
- **NPK Nutrient Guide** - Understand plant nutrition
- **Multi-language Support** - English, Hindi, Telugu
- **Dark/Light Theme** - Toggle between themes

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, Vite, Tailwind CSS, React Router |
| Backend | Node.js, Express.js |
| Database | SQLite (via better-sqlite3) |
| AI | Claude API (Anthropic) |

---

## Troubleshooting

### "node is not recognized"
Node.js is not installed or not in your PATH. Download and install from https://nodejs.org/

### "npm ERR! code ENOENT"
You're in the wrong directory. Make sure you `cd` into the correct folder before running `npm install`.

### "ANTHROPIC_API_KEY is not set"
Check that the `.env` file exists in the `krishimitra/` root folder (not inside `server/` or `client/`).

### Port 5000 already in use
Change the `PORT` value in `.env` to another port (e.g., `PORT=5001`), then restart the server.

### SQLite build errors on Windows
If `better-sqlite3` fails to install, you may need build tools:
```bash
npm install --global windows-build-tools
```
Or install Visual Studio Build Tools from https://visualstudio.microsoft.com/visual-cpp-build-tools/

---

## API Key Info

This project uses the **Anthropic Claude API** for AI features. The included API key is pre-configured. If the key expires or you need your own:

1. Go to https://console.anthropic.com/
2. Create an account and generate an API key
3. Replace the key in `.env`
