import { useState, useRef } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { apiFetch } from '../lib/api';
import npkData from '../data/npkData';
import NPKCard from '../components/NPKCard';

const ANALYSIS_HINTS = [
  'Examining leaf coloration...',
  'Checking nitrogen levels...',
  'Analyzing phosphorus indicators...',
  'Evaluating potassium status...',
  'Generating recommendations...',
];

function NPKStatusBadge({ status }) {
  const styles = {
    Deficient: 'bg-error/10 text-error border-error/20',
    Sufficient: 'bg-accent/10 text-accent border-accent/20',
    Excess: 'bg-secondary/10 text-secondary border-secondary/20',
  };
  return (
    <span className={`inline-block px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest border ${styles[status] || 'bg-surface-bright text-text-secondary'}`}>
      {status}
    </span>
  );
}

function HealthBadge({ health }) {
  const styles = {
    Healthy: 'bg-accent/10 text-accent border-accent/20',
    'Mild Deficiency': 'bg-secondary/10 text-secondary border-secondary/20',
    'Moderate Deficiency': 'bg-secondary/15 text-secondary border-secondary/30',
    'Severe Deficiency': 'bg-error/10 text-error border-error/20',
  };
  return (
    <span className={`inline-block px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider border ${styles[health] || 'bg-surface-bright text-text-secondary'}`}>
      {health}
    </span>
  );
}

function NutrientResult({ label, symbol, color, data }) {
  const confidence = parseInt(data.confidence, 10) || 0;
  return (
    <div className="bg-surface-card ghost-border rounded-2xl p-5">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-3">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-black text-sm"
            style={{ backgroundColor: color }}
          >
            {symbol}
          </div>
          <span className="font-bold text-text-primary">{label}</span>
        </div>
        <NPKStatusBadge status={data.status} />
      </div>
      {/* Confidence bar */}
      <div className="mb-3">
        <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest text-text-secondary mb-1.5">
          <span>Confidence</span>
          <span>{confidence}%</span>
        </div>
        <div className="w-full h-2 bg-surface-lowest rounded-full overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-700"
            style={{
              width: `${confidence}%`,
              background: `linear-gradient(90deg, ${color}80 0%, ${color} 100%)`,
              boxShadow: `0 0 8px ${color}40`,
            }}
          />
        </div>
      </div>
      <p className="text-sm text-text-secondary leading-relaxed">{data.observations}</p>
    </div>
  );
}

function LeafAnalysisResult({ result }) {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-surface-card ghost-border rounded-2xl p-6">
        <div className="flex items-center justify-between flex-wrap gap-4 mb-4">
          <div>
            <h3 className="text-xl font-bold text-text-primary">Leaf Analysis Complete</h3>
            {result.crop_detected && result.crop_detected !== 'Unknown' && (
              <p className="text-sm text-text-secondary mt-1">
                Detected crop: <span className="text-accent font-semibold">{result.crop_detected}</span>
              </p>
            )}
          </div>
          <HealthBadge health={result.overall_health} />
        </div>

        {/* Leaf color analysis */}
        <div className="bg-surface-lowest rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-1.5 h-1.5 rounded-full bg-accent" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-text-secondary">Leaf Color Analysis</span>
          </div>
          <p className="text-sm text-text-primary leading-relaxed">{result.leaf_color_analysis}</p>
        </div>
      </div>

      {/* NPK Status Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <NutrientResult label="Nitrogen" symbol="N" color="#22c55e" data={result.nitrogen} />
        <NutrientResult label="Phosphorus" symbol="P" color="#a855f7" data={result.phosphorus} />
        <NutrientResult label="Potassium" symbol="K" color="#f97316" data={result.potassium} />
      </div>

      {/* Issues + Recommendations */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Issues */}
        <div className="bg-surface-card ghost-border rounded-2xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <span className="w-1.5 h-1.5 rounded-full bg-error" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-error/80">Issues Identified</span>
          </div>
          <ul className="space-y-2">
            {result.identified_issues?.map((issue, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-text-secondary">
                <span className="material-symbols-outlined text-error text-base mt-0.5 shrink-0">warning</span>
                {issue}
              </li>
            ))}
          </ul>
        </div>

        {/* Recommendations */}
        <div className="bg-accent/5 border border-accent/20 rounded-2xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <span className="w-1.5 h-1.5 rounded-full bg-accent" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-accent">Recommendations</span>
          </div>
          <ul className="space-y-2">
            {result.recommendations?.map((rec, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-text-secondary">
                <span className="material-symbols-outlined text-accent text-base mt-0.5 shrink-0">check_circle</span>
                {rec}
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Summary */}
      <div className="bg-surface-card ghost-border rounded-2xl p-6">
        <div className="flex items-center gap-2 mb-3">
          <span className="w-1.5 h-1.5 rounded-full bg-accent" />
          <span className="text-[10px] font-bold uppercase tracking-widest text-text-secondary">Expert Summary</span>
        </div>
        <blockquote className="border-l-4 border-accent bg-surface-lowest rounded-r-xl p-4 text-sm text-text-primary leading-relaxed italic">
          {result.summary}
        </blockquote>
      </div>
    </div>
  );
}

export default function NPKGuide() {
  const { t, language } = useLanguage();
  const [leafImage, setLeafImage] = useState(null);
  const [leafPreview, setLeafPreview] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [leafResult, setLeafResult] = useState(null);
  const [leafError, setLeafError] = useState('');
  const [hintIndex, setHintIndex] = useState(0);
  const fileInputRef = useRef(null);
  const hintIntervalRef = useRef(null);

  const handleFileSelect = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setLeafError('Please select an image file');
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setLeafError('Image must be under 10MB');
      return;
    }

    setLeafError('');
    setLeafResult(null);

    const reader = new FileReader();
    reader.onload = (ev) => {
      setLeafPreview(ev.target.result);
      const base64 = ev.target.result.replace(/^data:image\/[a-zA-Z+]+;base64,/, '');
      setLeafImage(base64);
    };
    reader.readAsDataURL(file);
  };

  const handleAnalyze = async () => {
    if (!leafImage || analyzing) return;
    setAnalyzing(true);
    setLeafError('');
    setHintIndex(0);

    hintIntervalRef.current = setInterval(() => {
      setHintIndex((prev) => (prev + 1) % ANALYSIS_HINTS.length);
    }, 2500);

    try {
      const data = await apiFetch('/soil/leaf-npk', {
        method: 'POST',
        body: { image: leafImage, language },
      });
      setLeafResult(data.result);
    } catch (err) {
      setLeafError(err.message || 'Analysis failed. Please try again.');
    } finally {
      setAnalyzing(false);
      clearInterval(hintIntervalRef.current);
    }
  };

  const resetAnalysis = () => {
    setLeafImage(null);
    setLeafPreview(null);
    setLeafResult(null);
    setLeafError('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="py-8">
      {/* Hero Banner */}
      <div className="relative rounded-2xl overflow-hidden mb-8">
        <img
          src="https://images.unsplash.com/photo-1530836369250-ef72a3f5cda8?w=800&q=80"
          alt="Leaf analysis"
          className="w-full h-36 md:h-48 object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/40 to-transparent" />
        <div className="absolute inset-0 flex flex-col justify-center px-6 md:px-8">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-green-300">
              Nutrient Management
            </span>
          </div>
          <h1 className="text-2xl md:text-3xl font-black tracking-tight text-white drop-shadow-lg">
            {t('npk.title')}
          </h1>
        </div>
      </div>

      {/* ===== LEAF ANALYSIS SECTION ===== */}
      <div className="bg-surface-card ghost-border rounded-2xl p-6 md:p-8 mb-10">
        <div className="flex items-start gap-4 mb-6">
          <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center shrink-0">
            <span className="material-symbols-outlined text-accent text-2xl">local_florist</span>
          </div>
          <div>
            <h2 className="text-xl font-bold text-text-primary">Leaf NPK Analyzer</h2>
            <p className="text-sm text-text-secondary mt-1">
              Upload a photo of your crop's leaf to detect Nitrogen, Phosphorus, and Potassium levels through AI-powered color analysis.
            </p>
          </div>
        </div>

        {!leafResult && !analyzing && (
          <div className="space-y-4">
            {/* Upload zone */}
            {!leafPreview ? (
              <label className="block cursor-pointer">
                <div className="border-2 border-dashed border-text-secondary/20 rounded-2xl p-10 text-center hover:border-accent/40 transition-colors bg-surface-lowest">
                  <div className="w-16 h-16 rounded-2xl bg-accent/10 flex items-center justify-center mx-auto mb-4">
                    <span className="material-symbols-outlined text-accent text-3xl">eco</span>
                  </div>
                  <p className="text-text-primary font-semibold mb-1">Upload Leaf Image</p>
                  <p className="text-sm text-text-secondary">Take a close-up photo of a single leaf in natural light</p>
                  <p className="text-xs text-text-secondary/60 mt-2">JPEG, PNG or WebP - Max 10MB</p>
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  capture="environment"
                  onChange={handleFileSelect}
                  className="hidden"
                />
              </label>
            ) : (
              <div className="relative">
                <img
                  src={leafPreview}
                  alt="Leaf preview"
                  className="w-full max-h-80 object-contain rounded-2xl bg-surface-lowest ghost-border"
                />
                <button
                  onClick={resetAnalysis}
                  className="absolute top-3 right-3 w-8 h-8 rounded-full bg-surface/80 backdrop-blur-sm text-text-secondary hover:text-error hover:bg-error/10 flex items-center justify-center transition-all"
                >
                  <span className="material-symbols-outlined text-lg">close</span>
                </button>
              </div>
            )}

            {leafError && (
              <div className="flex items-center gap-2 text-error text-sm bg-error/10 px-4 py-3 rounded-xl">
                <span className="material-symbols-outlined text-base">error</span>
                {leafError}
              </div>
            )}

            {leafPreview && (
              <button
                onClick={handleAnalyze}
                className="w-full py-4 bg-gradient-to-r from-accent to-accent-container text-accent-on font-bold rounded-full transition-all hover:brightness-110 active:scale-[0.98] flex items-center justify-center gap-2"
                style={{ boxShadow: '0 8px 30px rgba(75, 226, 119, 0.15)' }}
              >
                <span className="material-symbols-outlined">biotech</span>
                Analyze Leaf for NPK
              </button>
            )}
          </div>
        )}

        {/* Analyzing state */}
        {analyzing && (
          <div className="flex flex-col items-center py-12 gap-4">
            <div className="relative">
              <div className="w-16 h-16 rounded-full border-4 border-accent/20 border-t-accent animate-spin" />
              <div className="absolute inset-0 w-16 h-16 rounded-full animate-ping bg-accent/10" />
            </div>
            <p className="text-sm text-accent font-semibold">{ANALYSIS_HINTS[hintIndex]}</p>
            {leafPreview && (
              <img src={leafPreview} alt="Analyzing" className="w-24 h-24 object-cover rounded-xl opacity-50 mt-2" />
            )}
          </div>
        )}

        {/* Result */}
        {leafResult && (
          <div className="space-y-6">
            <LeafAnalysisResult result={leafResult} />
            <button
              onClick={resetAnalysis}
              className="w-full py-3 ghost-border rounded-full text-text-primary font-semibold hover:bg-surface-hover transition-all flex items-center justify-center gap-2"
            >
              <span className="material-symbols-outlined">refresh</span>
              Analyze Another Leaf
            </button>
          </div>
        )}
      </div>

      {/* ===== REFERENCE GUIDE (hidden when results showing) ===== */}
      {!leafResult && (
        <>
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <span className="w-2 h-2 rounded-full bg-accent" />
              <span className="text-[10px] font-bold uppercase tracking-widest text-text-secondary">
                Reference Guide
              </span>
            </div>
            <h2 className="text-2xl font-bold text-text-primary tracking-tight">
              NPK Deficiency Identification
            </h2>
          </div>

          <div className="space-y-12">
            <NPKCard nutrient={npkData.nitrogen} />
            <NPKCard nutrient={npkData.phosphorus} />
            <NPKCard nutrient={npkData.potassium} />
          </div>
        </>
      )}
    </div>
  );
}
