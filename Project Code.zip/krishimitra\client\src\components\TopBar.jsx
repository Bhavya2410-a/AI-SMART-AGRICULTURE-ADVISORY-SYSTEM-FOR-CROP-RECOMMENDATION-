import { useState, useRef, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import ThemeToggle from './ThemeToggle';
import LanguageSelector from './LanguageSelector';

const pageLabels = {
  '/': 'nav.dashboard',
  '/soil-scan': 'nav.soilScan',
  '/soil-types': 'nav.soilTypes',
  '/npk-guide': 'nav.npkGuide',
  '/advisories': 'nav.advisories',
  '/voice': 'nav.voice',
  '/profile': 'nav.profile',
  '/help': 'nav.help',
};

function maskPhone(phone) {
  if (!phone || phone.length < 6) return phone || '';
  return '+91 ' + phone.slice(0, 2) + '****' + phone.slice(-2);
}

export default function TopBar() {
  const { user, logout } = useAuth();
  const { t } = useLanguage();
  const location = useLocation();
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef(null);

  const initial = user?.phone ? user.phone.charAt(0) : '?';
  const currentPage = pageLabels[location.pathname] || 'nav.dashboard';

  // Close menu on click outside
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setMenuOpen(false);
      }
    };
    if (menuOpen) document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [menuOpen]);

  // Close menu on route change
  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  const handleLogout = () => {
    if (window.confirm(t('profile.logoutConfirm'))) {
      logout();
      navigate('/login');
    }
  };

  return (
    <header className="fixed top-0 right-0 left-0 md:left-64 z-40 h-16 flex items-center justify-between px-4 md:px-8" style={{ backgroundColor: 'rgba(15, 20, 26, 0.8)', backdropFilter: 'blur(16px)', borderBottom: '1px solid rgba(134, 149, 133, 0.15)' }}>
      {/* Left */}
      <div className="flex items-center gap-2 min-w-0">
        <span className="md:hidden text-xl">🌿</span>
        <span className="md:hidden text-lg font-bold text-accent tracking-tight">KrishiMitra</span>
        <span className="hidden md:block text-sm font-semibold text-text-primary">{t(currentPage)}</span>
      </div>

      {/* Right */}
      <div className="flex items-center gap-4 shrink-0">
        <ThemeToggle />
        <LanguageSelector />

        {/* Profile avatar + dropdown */}
        <div className="relative" ref={menuRef}>
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="relative focus:outline-none"
          >
            <div className="w-9 h-9 rounded-full bg-accent-container flex items-center justify-center text-accent-on text-sm font-bold transition-transform hover:scale-105 active:scale-95">
              {initial}
            </div>
            <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-accent border-2" style={{ borderColor: 'var(--bg-primary)' }} />
          </button>

          {/* Dropdown menu */}
          {menuOpen && (
            <div className="absolute right-0 top-full mt-2 w-56 rounded-xl bg-surface-card ghost-border overflow-hidden shadow-xl shadow-black/20 z-50">
              {/* User info */}
              <div className="px-4 py-3 border-b border-border">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-accent-container flex items-center justify-center text-accent-on font-bold">
                    {initial}
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-text-primary truncate">
                      {maskPhone(user?.phone)}
                    </p>
                    <p className="text-[10px] uppercase tracking-wider text-text-secondary">Farmer</p>
                  </div>
                </div>
              </div>

              {/* Menu items */}
              <div className="py-1">
                <button
                  onClick={() => { navigate('/profile'); setMenuOpen(false); }}
                  className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-text-primary hover:bg-surface-hover transition-colors"
                >
                  <span className="material-symbols-outlined text-lg text-text-secondary">person</span>
                  {t('profile.title')}
                </button>
                <button
                  onClick={() => { navigate('/help'); setMenuOpen(false); }}
                  className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-text-primary hover:bg-surface-hover transition-colors"
                >
                  <span className="material-symbols-outlined text-lg text-text-secondary">help</span>
                  {t('help.title')}
                </button>
              </div>

              {/* Logout */}
              <div className="border-t border-border py-1">
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-error hover:bg-error/10 transition-colors"
                >
                  <span className="material-symbols-outlined text-lg">logout</span>
                  {t('profile.logout')}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
