const advisoryData = [
  {
    id: 1,
    tag: 'Seasonal',
    imageUrl: 'https://images.unsplash.com/photo-1536657464919-892534f60d6e?w=600&q=80',
    title: 'Kharif Season Preparation',
    season: 'June - October',
    description:
      'Prepare fields for monsoon sowing. The kharif season is crucial for rain-fed agriculture across India.',
    tips: [
      'Prepare nursery beds for rice by mid-June',
      'Apply basal dose of fertilizers before sowing',
      'Ensure proper drainage channels are cleared',
      'Select disease-resistant seed varieties',
    ],
    crops: ['Rice', 'Maize', 'Cotton', 'Soybean', 'Groundnut'],
  },
  {
    id: 2,
    tag: 'Seasonal',
    imageUrl: 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=600&q=80',
    title: 'Rabi Season Planning',
    season: 'October - March',
    description:
      'Winter crop planning and field preparation. Rabi crops depend on residual moisture and irrigation.',
    tips: [
      'Begin wheat sowing by mid-November',
      'Apply recommended dose of DAP at sowing',
      'Plan irrigation schedule for dry months',
      'Monitor for aphid and rust diseases',
    ],
    crops: ['Wheat', 'Mustard', 'Chickpea', 'Peas', 'Barley'],
  },
  {
    id: 3,
    tag: 'Urgent',
    imageUrl: 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=600&q=80',
    title: 'Pest Alert: Fall Armyworm',
    season: 'Year-round',
    description:
      'Monitor maize and millet crops for fall armyworm infestation. Early detection is key to preventing crop loss.',
    tips: [
      'Scout fields early morning for egg masses',
      'Use pheromone traps at 5 per acre',
      'Apply neem-based pesticide at first sign',
      'Report severe infestation to local KVK',
    ],
    crops: ['Maize', 'Millet', 'Sorghum'],
  },
  {
    id: 4,
    tag: 'Tip',
    imageUrl: 'https://images.unsplash.com/photo-1468421870903-4df1664ac249?w=600&q=80',
    title: 'Water Conservation Techniques',
    season: 'Year-round',
    description:
      'Implement efficient water management practices to conserve this precious resource and reduce costs.',
    tips: [
      'Use drip irrigation to save 40-60% water',
      'Apply mulching to reduce evaporation',
      'Practice alternate wetting and drying in paddy',
      'Harvest rainwater in farm ponds',
    ],
    crops: [],
  },
  {
    id: 5,
    tag: 'Tip',
    imageUrl: 'https://images.unsplash.com/photo-1592982537447-6f2a6a0c7c18?w=600&q=80',
    title: 'Organic Farming Practices',
    season: 'Year-round',
    description:
      'Transition to sustainable organic methods for healthier soil and premium market prices.',
    tips: [
      'Prepare vermicompost from crop residues',
      'Use Jeevamrutha as organic growth promoter',
      'Practice crop rotation to maintain soil health',
      'Use bio-pesticides like Trichoderma and Pseudomonas',
    ],
    crops: [],
  },
];

export default advisoryData;
