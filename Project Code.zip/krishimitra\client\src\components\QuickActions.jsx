import { Link } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

const actions = [
  {
    to: '/soil-scan',
    titleKey: 'dashboard.scanSoil',
    descKey: 'dashboard.scanSoilDesc',
    materialIcon: 'photo_camera',
    imageUrl: 'https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=400&q=80',
  },
  {
    to: '/voice',
    titleKey: 'dashboard.voiceAssistant',
    descKey: 'dashboard.voiceAssistantDesc',
    materialIcon: 'mic',
    imageUrl: 'https://images.unsplash.com/photo-1593642632559-0c6d3fc62b89?w=400&q=80',
  },
  {
    to: '/soil-types',
    titleKey: 'dashboard.soilGuide',
    descKey: 'dashboard.soilGuideDesc',
    materialIcon: 'public',
    imageUrl: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=400&q=80',
  },
  {
    to: '/npk-guide',
    titleKey: 'dashboard.npkGuide',
    descKey: 'dashboard.npkGuideDesc',
    materialIcon: 'eco',
    imageUrl: 'https://images.unsplash.com/photo-1530836369250-ef72a3f5cda8?w=400&q=80',
  },
];

export default function QuickActions() {
  const { t } = useLanguage();

  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <div className="w-2 h-2 rounded-full bg-accent" />
        <h3 className="text-[10px] font-bold uppercase tracking-[0.15em] text-text-secondary">
          {t('dashboard.quickActions')}
        </h3>
      </div>
      <div className="grid grid-cols-2 gap-4">
        {actions.map((action) => (
          <Link
            key={action.to}
            to={action.to}
            className="relative rounded-2xl overflow-hidden group block h-44 md:h-48"
          >
            {/* Background photo */}
            <img
              src={action.imageUrl}
              alt=""
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              loading="lazy"
            />
            {/* Gradient overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-black/10 group-hover:from-black/70 transition-all duration-300" />

            {/* Content */}
            <div className="absolute inset-0 flex flex-col justify-end p-5 z-10">
              <div className="w-10 h-10 rounded-xl bg-white/15 backdrop-blur-sm flex items-center justify-center mb-3 border border-white/10 group-hover:scale-110 transition-transform duration-300">
                <span className="material-symbols-outlined text-white" style={{ fontSize: '20px' }}>
                  {action.materialIcon}
                </span>
              </div>
              <p className="font-bold text-white text-base leading-tight drop-shadow-lg">
                {t(action.titleKey)}
              </p>
              <p className="text-xs text-white/60 mt-1 leading-relaxed line-clamp-2">
                {t(action.descKey)}
              </p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
