export default function LoadingSpinner({ size = 'md', text }) {
  const sizes = {
    sm: 'w-6 h-6',
    md: 'w-10 h-10',
    lg: 'w-16 h-16',
  };

  return (
    <div className="flex flex-col items-center justify-center gap-4">
      <div className="relative">
        <svg
          className={`${sizes[size]} animate-spin text-accent`}
          viewBox="0 0 24 24"
          fill="none"
        >
          <circle
            className="opacity-10"
            cx="12"
            cy="12"
            r="10"
            stroke="currentColor"
            strokeWidth="3"
          />
          <path
            className="opacity-90"
            fill="currentColor"
            d="M4 12a8 8 0 018-8v3a5 5 0 00-5 5H4z"
          />
        </svg>
        <div className="absolute inset-0 rounded-full bg-accent/5 animate-ping" style={{ animationDuration: '2s' }} />
      </div>
      {text && (
        <p className="text-text-secondary text-sm font-medium animate-pulse tracking-wide">{text}</p>
      )}
    </div>
  );
}
