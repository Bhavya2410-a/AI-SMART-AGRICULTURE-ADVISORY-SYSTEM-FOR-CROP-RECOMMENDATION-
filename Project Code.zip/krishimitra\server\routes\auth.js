const express = require('express');
const crypto = require('crypto');
const db = require('../db');

const router = express.Router();

// POST /login
router.post('/login', (req, res) => {
  try {
    const { phone } = req.body;

    if (!phone || !/^[6-9]\d{9}$/.test(phone)) {
      return res.status(400).json({ success: false, error: 'Invalid phone number. Must be a 10-digit Indian mobile number.' });
    }

    const token = crypto.randomBytes(32).toString('hex');
    let user = db.prepare('SELECT id, phone, language, theme, created_at FROM users WHERE phone = ?').get(phone);

    if (user) {
      db.prepare('UPDATE users SET token = ? WHERE id = ?').run(token, user.id);
    } else {
      const result = db.prepare('INSERT INTO users (phone, token) VALUES (?, ?)').run(phone, token);
      user = db.prepare('SELECT id, phone, language, theme, created_at FROM users WHERE id = ?').get(result.lastInsertRowid);
    }

    res.json({ success: true, data: { user, token } });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Login failed' });
  }
});

module.exports = router;
