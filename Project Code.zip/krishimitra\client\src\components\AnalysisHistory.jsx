import { useState, useEffect, useCallback } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { apiFetch } from '../lib/api';
import AnalysisResult from './AnalysisResult';
import LoadingSpinner from './LoadingSpinner';

function ConditionBadge({ condition }) {
  const colors = {
    Good: 'bg-accent/10 text-accent border border-accent/20',
    Moderate: 'bg-secondary/10 text-secondary border border-secondary/20',
    Poor: 'bg-error/10 text-error border border-error/20',
  };

  return (
    <span
      className={`inline-block px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${
        colors[condition] || 'bg-surface-bright text-text-secondary'
      }`}
    >
      {condition}
    </span>
  );
}

function HistoryItem({ item, isExpanded, onToggle }) {
  const { t } = useLanguage();
  const raw = item.result || item.result_json;
  const result =
    typeof raw === 'string'
      ? JSON.parse(raw)
      : raw;

  const date = new Date(item.created_at || item.createdAt).toLocaleDateString(
    undefined,
    { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }
  );

  return (
    <div className="bg-surface-card rounded-2xl ghost-border overflow-hidden transition-all duration-300 hover:border-accent/20">
      <button
        onClick={onToggle}
        className="w-full text-left p-5 flex items-center justify-between gap-4 hover:bg-surface-hover transition-colors duration-200"
      >
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2.5 flex-wrap">
            <span className="text-text-primary font-bold text-base">{result?.soil_type || t('soil.soilType')}</span>
            {result?.soil_condition && <ConditionBadge condition={result.soil_condition} />}
          </div>
          <div className="flex items-center gap-3 mt-2 text-xs text-text-secondary">
            <span className="flex items-center gap-1">
              <span className="material-symbols-outlined text-sm">schedule</span>
              {date}
            </span>
            {result?.moisture && (
              <span className="flex items-center gap-1">
                <span className="material-symbols-outlined text-sm">water_drop</span>
                {result.moisture}
              </span>
            )}
          </div>
        </div>
        <span
          className={`material-symbols-outlined text-text-secondary transition-transform duration-300 ${
            isExpanded ? 'rotate-180' : ''
          }`}
        >
          expand_more
        </span>
      </button>

      {isExpanded && (
        <div className="border-t border-text-secondary/5 p-5">
          <AnalysisResult result={result} />
        </div>
      )}
    </div>
  );
}

export default function AnalysisHistory() {
  const { t } = useLanguage();
  const [items, setItems] = useState([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [loading, setLoading] = useState(true);
  const [expandedId, setExpandedId] = useState(null);
  const [error, setError] = useState('');

  const fetchHistory = useCallback(async (pageNum) => {
    try {
      setLoading(true);
      setError('');
      const data = await apiFetch(`/soil/history?page=${pageNum}&limit=10`);
      const analyses = data.analyses || data || [];

      if (pageNum === 1) {
        setItems(analyses);
      } else {
        setItems((prev) => [...prev, ...analyses]);
      }

      setHasMore(analyses.length === 10);
    } catch (err) {
      setError(err.message || 'Failed to load history');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchHistory(1);
  }, [fetchHistory]);

  const loadMore = () => {
    const next = page + 1;
    setPage(next);
    fetchHistory(next);
  };

  const toggleExpand = (id) => {
    setExpandedId((prev) => (prev === id ? null : id));
  };

  if (loading && items.length === 0) {
    return (
      <div className="flex justify-center py-20">
        <LoadingSpinner text={t('soil.history')} />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-20">
        <div className="w-16 h-16 rounded-2xl bg-error/10 flex items-center justify-center mx-auto mb-4">
          <span className="material-symbols-outlined text-error text-3xl">error</span>
        </div>
        <p className="text-error text-sm font-medium">{error}</p>
        <button
          onClick={() => fetchHistory(1)}
          className="mt-4 px-6 py-2.5 text-sm font-semibold text-accent ghost-border rounded-full hover:bg-surface-hover transition-all duration-200"
        >
          Retry
        </button>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="text-center py-20">
        <div className="w-20 h-20 rounded-2xl bg-surface-lowest flex items-center justify-center mx-auto mb-5">
          <span className="text-5xl">🔬</span>
        </div>
        <p className="text-text-primary text-lg font-bold">{t('soil.noHistory')}</p>
        <p className="text-text-secondary text-sm mt-2 max-w-xs mx-auto">
          {t('soil.uploadHint')}
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {items.map((item, idx) => (
        <HistoryItem
          key={item.id || idx}
          item={item}
          isExpanded={expandedId === (item.id || idx)}
          onToggle={() => toggleExpand(item.id || idx)}
        />
      ))}

      {hasMore && (
        <div className="text-center pt-4">
          <button
            onClick={loadMore}
            disabled={loading}
            className="px-8 py-3 text-sm font-bold text-accent ghost-border rounded-full hover:bg-surface-hover hover:border-accent/30 transition-all duration-200 disabled:opacity-50"
          >
            {loading ? t('soil.analyzing') : 'Load More'}
          </button>
        </div>
      )}
    </div>
  );
}
