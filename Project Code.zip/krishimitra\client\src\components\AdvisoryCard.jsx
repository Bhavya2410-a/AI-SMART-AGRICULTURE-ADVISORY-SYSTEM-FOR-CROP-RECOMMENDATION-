import { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';

const tagStyles = {
  Urgent: 'bg-error/10 text-error border border-error/20',
  Seasonal: 'bg-accent/10 text-accent border border-accent/20',
  Tip: 'bg-secondary/10 text-secondary border border-secondary/20',
};

const hoverBorderColors = {
  Urgent: 'hover:border-error/30',
  Seasonal: 'hover:border-accent/30',
  Tip: 'hover:border-secondary/30',
};

const tagIcons = {
  Urgent: 'warning',
  Seasonal: 'calendar_month',
  Tip: 'lightbulb',
};

export default function AdvisoryCard({ advisory }) {
  const [expanded, setExpanded] = useState(false);
  const { t } = useLanguage();

  const tagLabel =
    advisory.tag === 'Urgent'
      ? t('advisory.urgent')
      : advisory.tag === 'Seasonal'
        ? t('advisory.seasonal')
        : t('advisory.tip');

  return (
    <div
      className={`bg-surface-card rounded-2xl overflow-hidden cursor-pointer transition-all duration-300 hover:-translate-y-1 hover:shadow-lg ghost-border ${hoverBorderColors[advisory.tag] || ''}`}
      onClick={() => setExpanded(!expanded)}
    >
      <div className="flex">
        {/* Side image */}
        {advisory.imageUrl && (
          <div className="hidden sm:block w-32 shrink-0 relative overflow-hidden">
            <img
              src={advisory.imageUrl}
              alt=""
              className="w-full h-full object-cover"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-transparent to-surface-card/80" />
          </div>
        )}

        <div className="flex-1 p-6">
          {/* Header row */}
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2.5 mb-3">
                <span
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-widest ${tagStyles[advisory.tag]}`}
                >
                  <span className="material-symbols-outlined text-xs">{tagIcons[advisory.tag]}</span>
                  {tagLabel}
                </span>
                <span className="text-xs text-text-secondary font-medium">{advisory.season}</span>
              </div>
              <h3 className="text-base font-bold text-text-primary leading-snug">{advisory.title}</h3>
            </div>
            <span
              className={`material-symbols-outlined text-text-secondary shrink-0 mt-1 transition-transform duration-300 ${expanded ? 'rotate-180' : ''}`}
            >
              expand_more
            </span>
          </div>
        </div>
      </div>

      {/* Expandable content */}
      <div
        className={`overflow-hidden transition-all duration-300 ease-in-out ${expanded ? 'max-h-[600px] opacity-100' : 'max-h-0 opacity-0'}`}
      >
        <div className="px-6 pb-6 border-t border-text-secondary/5 pt-5">
          <p className="text-sm text-text-secondary mb-5 leading-relaxed">{advisory.description}</p>

          <div className="bg-surface-lowest rounded-xl p-5 mb-5">
            <div className="flex items-center gap-2 mb-3">
              <span className="w-1.5 h-1.5 rounded-full bg-accent" />
              <span className="text-[10px] font-bold uppercase tracking-widest text-text-secondary">Action Items</span>
            </div>
            <ul className="space-y-3">
              {advisory.tips.map((tip, i) => (
                <li key={i} className="flex items-start gap-3 text-sm text-text-primary">
                  <span className="mt-0.5 text-accent flex-shrink-0">
                    <span className="material-symbols-outlined text-lg">check_circle</span>
                  </span>
                  <span className="leading-relaxed">{tip}</span>
                </li>
              ))}
            </ul>
          </div>

          {advisory.crops.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-3">
                <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                <span className="text-[10px] font-bold uppercase tracking-widest text-text-secondary">Applicable Crops</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {advisory.crops.map((crop, i) => (
                  <span
                    key={i}
                    className="text-xs px-3.5 py-1.5 rounded-full bg-accent/10 text-accent font-semibold border border-accent/10"
                  >
                    {crop}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
