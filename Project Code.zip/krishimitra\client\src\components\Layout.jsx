import { useLocation } from 'react-router-dom';
import TopBar from './TopBar';
import Sidebar from './Sidebar';
import BottomNav from './BottomNav';

export default function Layout({ children }) {
  const location = useLocation();
  const isVoicePage = location.pathname === '/voice';

  return (
    <div className="min-h-screen bg-surface">
      <Sidebar />
      <TopBar />

      <main className={`md:ml-64 ${isVoicePage ? 'pt-16' : 'pt-24 md:pt-24 px-4 md:px-8 pb-24 md:pb-8'}`}>
        <div className={isVoicePage ? '' : 'max-w-7xl mx-auto'}>
          {children}
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
