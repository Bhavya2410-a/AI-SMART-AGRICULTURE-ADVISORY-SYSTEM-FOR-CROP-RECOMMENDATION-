const express = require('express');
const authMiddleware = require('../middleware/auth');
const db = require('../db');
const { voiceQuery } = require('../services/claude');

const router = express.Router();

// POST /query — accepts optional messages array for conversation history
router.post('/query', authMiddleware, async (req, res) => {
  try {
    const { text, language, messages } = req.body;

    if (!text || !text.trim()) {
      return res.status(400).json({ success: false, error: 'Text is required' });
    }

    const response = await voiceQuery(text, language || 'en-US', messages);

    res.json({ success: true, data: { response } });
  } catch (error) {
    console.error('Voice query error:', error);
    res.status(500).json({ success: false, error: 'Voice query failed. Please try again.' });
  }
});

// POST /session/save — save or update a chat session
router.post('/session/save', authMiddleware, (req, res) => {
  try {
    const { sessionId, messages } = req.body;

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ success: false, error: 'Messages array is required' });
    }

    const messagesJson = JSON.stringify(messages);

    if (sessionId) {
      // Update existing session
      const existing = db.prepare(
        'SELECT id FROM chat_sessions WHERE id = ? AND user_id = ?'
      ).get(sessionId, req.user.id);

      if (!existing) {
        return res.status(404).json({ success: false, error: 'Session not found' });
      }

      db.prepare(
        "UPDATE chat_sessions SET messages_json = ?, updated_at = datetime('now') WHERE id = ?"
      ).run(messagesJson, sessionId);

      res.json({ success: true, data: { id: sessionId } });
    } else {
      // Create new session
      const result = db.prepare(
        'INSERT INTO chat_sessions (user_id, messages_json) VALUES (?, ?)'
      ).run(req.user.id, messagesJson);

      res.json({ success: true, data: { id: result.lastInsertRowid } });
    }
  } catch (error) {
    console.error('Session save error:', error);
    res.status(500).json({ success: false, error: 'Failed to save session' });
  }
});

// GET /sessions — list past chat sessions
router.get('/sessions', authMiddleware, (req, res) => {
  try {
    const rows = db.prepare(
      'SELECT id, messages_json, created_at, updated_at FROM chat_sessions WHERE user_id = ? ORDER BY updated_at DESC LIMIT 50'
    ).all(req.user.id);

    const sessions = rows.map(row => {
      let title = 'Chat';
      try {
        const msgs = JSON.parse(row.messages_json);
        // Find first user message as title
        const firstUser = msgs.find(m => m.role === 'user');
        if (firstUser) {
          const txt = firstUser.text || firstUser.content || '';
          title = txt.slice(0, 60) + (txt.length > 60 ? '...' : '');
        }
      } catch {}

      return {
        id: row.id,
        title,
        created_at: row.created_at,
        updated_at: row.updated_at,
      };
    });

    res.json({ success: true, data: { sessions } });
  } catch (error) {
    console.error('Sessions list error:', error);
    res.status(500).json({ success: false, error: 'Failed to fetch sessions' });
  }
});

// GET /session/:id — get full session messages
router.get('/session/:id', authMiddleware, (req, res) => {
  try {
    const row = db.prepare(
      'SELECT id, messages_json, created_at, updated_at FROM chat_sessions WHERE id = ? AND user_id = ?'
    ).get(req.params.id, req.user.id);

    if (!row) {
      return res.status(404).json({ success: false, error: 'Session not found' });
    }

    res.json({
      success: true,
      data: {
        id: row.id,
        messages: JSON.parse(row.messages_json),
        created_at: row.created_at,
        updated_at: row.updated_at,
      },
    });
  } catch (error) {
    console.error('Session fetch error:', error);
    res.status(500).json({ success: false, error: 'Failed to fetch session' });
  }
});

// DELETE /session/:id
router.delete('/session/:id', authMiddleware, (req, res) => {
  try {
    const result = db.prepare(
      'DELETE FROM chat_sessions WHERE id = ? AND user_id = ?'
    ).run(req.params.id, req.user.id);

    if (result.changes === 0) {
      return res.status(404).json({ success: false, error: 'Session not found' });
    }

    res.json({ success: true, data: { deleted: true } });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to delete session' });
  }
});

module.exports = router;
