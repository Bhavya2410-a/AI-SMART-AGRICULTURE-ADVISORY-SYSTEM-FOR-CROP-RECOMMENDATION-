const express = require('express');
const db = require('../db');
const authMiddleware = require('../middleware/auth');
const { analyzeSoil, analyzeLeafNPK } = require('../services/claude');

const router = express.Router();

// POST /analyze
router.post('/analyze', authMiddleware, async (req, res) => {
  try {
    const { image } = req.body;

    if (!image) {
      return res.status(400).json({ success: false, error: 'Image is required' });
    }

    // Strip data URI prefix if present
    const cleanBase64 = image.replace(/^data:image\/[a-zA-Z+]+;base64,/, '');

    const result = await analyzeSoil(cleanBase64);

    const insert = db.prepare(
      'INSERT INTO soil_analyses (user_id, image_base64, result_json) VALUES (?, ?, ?)'
    ).run(req.user.id, cleanBase64, JSON.stringify(result));

    const analysis = db.prepare(
      'SELECT id, created_at FROM soil_analyses WHERE id = ?'
    ).get(insert.lastInsertRowid);

    res.json({
      success: true,
      data: {
        id: analysis.id,
        result,
        created_at: analysis.created_at,
      },
    });
  } catch (error) {
    console.error('Soil analysis error:', error);
    res.status(500).json({ success: false, error: 'Soil analysis failed. Please try again.' });
  }
});

// GET /history
router.get('/history', authMiddleware, (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = Math.min(50, Math.max(1, parseInt(req.query.limit) || 10));
    const offset = (page - 1) * limit;

    const total = db.prepare(
      'SELECT COUNT(*) as count FROM soil_analyses WHERE user_id = ?'
    ).get(req.user.id).count;

    const rows = db.prepare(
      'SELECT id, result_json, created_at FROM soil_analyses WHERE user_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?'
    ).all(req.user.id, limit, offset);

    const analyses = rows.map(row => ({
      id: row.id,
      result: JSON.parse(row.result_json),
      created_at: row.created_at,
    }));

    res.json({ success: true, data: { analyses, total, page, limit } });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to fetch history' });
  }
});

// GET /analysis/:id
router.get('/analysis/:id', authMiddleware, (req, res) => {
  try {
    const analysis = db.prepare(
      'SELECT id, image_base64, result_json, created_at FROM soil_analyses WHERE id = ? AND user_id = ?'
    ).get(req.params.id, req.user.id);

    if (!analysis) {
      return res.status(404).json({ success: false, error: 'Analysis not found' });
    }

    res.json({
      success: true,
      data: {
        id: analysis.id,
        image_base64: analysis.image_base64,
        result: JSON.parse(analysis.result_json),
        created_at: analysis.created_at,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to fetch analysis' });
  }
});

// POST /leaf-npk — Analyze leaf image for NPK status
router.post('/leaf-npk', authMiddleware, async (req, res) => {
  try {
    const { image, language } = req.body;

    if (!image) {
      return res.status(400).json({ success: false, error: 'Image is required' });
    }

    const cleanBase64 = image.replace(/^data:image\/[a-zA-Z+]+;base64,/, '');
    const result = await analyzeLeafNPK(cleanBase64, language || 'en');

    res.json({ success: true, data: { result } });
  } catch (error) {
    console.error('Leaf NPK analysis error:', error);
    res.status(500).json({ success: false, error: 'Leaf analysis failed. Please try again.' });
  }
});

module.exports = router;
