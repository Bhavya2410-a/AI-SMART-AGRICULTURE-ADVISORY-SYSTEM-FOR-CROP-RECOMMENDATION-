import { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';

export default function SoilTypeCard({ soil }) {
  const [expanded, setExpanded] = useState(false);
  const { t } = useLanguage();

  return (
    <div
      className="bg-surface-card rounded-2xl overflow-hidden cursor-pointer transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-accent/5 ghost-border group"
      onClick={() => setExpanded(!expanded)}
    >
      {/* Photo header */}
      <div className="relative h-40 overflow-hidden">
        <img
          src={soil.imageUrl}
          alt={soil.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent" />

        {/* Soil name overlay */}
        <div className="absolute bottom-0 left-0 right-0 p-4">
          <h3 className="text-lg font-bold text-white leading-tight drop-shadow-lg">{soil.name}</h3>
          <p className="text-[10px] font-bold uppercase tracking-widest text-white/70 mt-1">
            {soil.region}
          </p>
        </div>

        {/* pH badge */}
        <div className="absolute top-3 right-3">
          <span
            className="text-[11px] font-bold px-3 py-1.5 rounded-full backdrop-blur-md bg-black/30 text-white border border-white/20"
          >
            pH {soil.ph}
          </span>
        </div>
      </div>

      <div className="p-5">
        {/* pH visual scale */}
        <div className="mb-4">
          <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-widest text-text-secondary mb-1.5">
            <span>Acidic</span>
            <span>Alkaline</span>
          </div>
          <div className="relative">
            <div className="ph-scale w-full" />
            {/* pH marker */}
            {(() => {
              const phLow = parseFloat(soil.ph);
              const position = ((phLow - 3) / 8) * 100;
              return (
                <div
                  className="absolute top-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-white border-2 shadow-md"
                  style={{ left: `${Math.min(Math.max(position, 2), 98)}%`, borderColor: soil.color }}
                />
              );
            })()}
          </div>
        </div>

        {/* Quick info chips */}
        <div className="flex flex-wrap gap-2 mb-3">
          {soil.bestCrops.slice(0, 3).map((crop, i) => (
            <span
              key={i}
              className="text-[10px] px-2.5 py-1 rounded-full bg-accent/10 text-accent font-semibold"
            >
              {crop}
            </span>
          ))}
          {soil.bestCrops.length > 3 && (
            <span className="text-[10px] px-2.5 py-1 rounded-full bg-surface-elevated text-text-secondary font-semibold">
              +{soil.bestCrops.length - 3}
            </span>
          )}
        </div>

        {/* Expand indicator */}
        <div className="flex items-center justify-center">
          <span
            className={`material-symbols-outlined text-text-secondary text-lg transition-transform duration-300 ${expanded ? 'rotate-180' : ''}`}
          >
            expand_more
          </span>
        </div>
      </div>

      {/* Expandable content */}
      <div
        className={`overflow-hidden transition-all duration-300 ease-in-out ${expanded ? 'max-h-[500px] opacity-100' : 'max-h-0 opacity-0'}`}
      >
        <div className="px-5 pb-5 pt-4 border-t border-text-secondary/5">
          {/* Characteristics */}
          <div className="flex items-center gap-2 mb-3">
            <span className="w-1.5 h-1.5 rounded-full bg-accent" />
            <p className="text-[10px] font-bold uppercase tracking-widest text-text-secondary">
              {t('soilTypes.characteristics')}
            </p>
          </div>
          <ul className="space-y-2 mb-5">
            {soil.characteristics.map((c, i) => (
              <li key={i} className="text-sm text-text-secondary flex items-start gap-2.5">
                <span className="material-symbols-outlined text-accent text-sm mt-0.5 shrink-0">check</span>
                {c}
              </li>
            ))}
          </ul>

          {/* Best Crops */}
          <div className="flex items-center gap-2 mb-3">
            <span className="w-1.5 h-1.5 rounded-full bg-accent" />
            <p className="text-[10px] font-bold uppercase tracking-widest text-text-secondary">
              {t('soilTypes.bestCrops')}
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            {soil.bestCrops.map((crop, i) => (
              <span
                key={i}
                className="text-xs px-3 py-1.5 rounded-lg bg-accent/10 text-accent font-semibold border border-accent/10"
              >
                {crop}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
