import { useLanguage } from '../context/LanguageContext';

function StatusBadge({ condition }) {
  const badgeColors = {
    Deficient: 'bg-error/10 text-error border border-error/20',
    Sufficient: 'bg-accent/10 text-accent border border-accent/20',
    Excess: 'bg-secondary/10 text-secondary border border-secondary/20',
  };

  return (
    <span
      className={`inline-block px-3 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-widest ${
        badgeColors[condition] || 'bg-surface-bright text-text-secondary'
      }`}
    >
      {condition}
    </span>
  );
}

export default function NPKCard({ nutrient }) {
  const { t } = useLanguage();

  return (
    <div>
      {/* Nutrient Header */}
      <div className="flex items-center gap-5 mb-6">
        <div
          className="w-14 h-14 rounded-full flex items-center justify-center text-white text-2xl font-black flex-shrink-0 ring-4 ring-offset-2 ring-offset-surface"
          style={{
            backgroundColor: nutrient.color,
            boxShadow: `0 0 30px ${nutrient.color}25, 0 0 60px ${nutrient.color}10`,
            ringColor: `${nutrient.color}30`,
          }}
        >
          {nutrient.symbol}
        </div>
        <div>
          <h2 className="text-xl md:text-2xl font-black text-text-primary tracking-tight">{nutrient.name}</h2>
          <p className="text-sm text-text-secondary mt-0.5">{nutrient.role}</p>
        </div>
      </div>

      {/* State Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {nutrient.states.map((state) => (
          <div
            key={state.condition}
            className="bg-surface-card rounded-2xl p-6 ghost-border hover:border-accent/20 transition-all duration-300 hover:-translate-y-0.5"
          >
            {/* Color swatch + condition */}
            <div className="flex items-center gap-3 mb-4">
              <div
                className="w-9 h-9 rounded-full flex-shrink-0"
                style={{
                  backgroundColor: state.color,
                  boxShadow: `0 4px 12px ${state.color}40`,
                }}
              />
              <div>
                <StatusBadge condition={state.condition} />
                <p className="text-xs text-text-secondary mt-1 font-medium">{state.leafColor}</p>
              </div>
            </div>

            {/* Description */}
            <p className="text-sm text-text-secondary mb-4 leading-relaxed">{state.description}</p>

            {/* Symptoms */}
            <div className="flex items-center gap-2 mb-2.5">
              <span className="w-1.5 h-1.5 rounded-full bg-accent" />
              <h4 className="text-[10px] font-bold uppercase tracking-widest text-text-secondary">
                {t('npk.symptoms')}
              </h4>
            </div>
            <ul className="space-y-1.5 mb-4">
              {state.symptoms.map((s, i) => (
                <li key={i} className="text-sm text-text-secondary flex items-start gap-2.5">
                  <span className="mt-1.5 w-1.5 h-1.5 rounded-full flex-shrink-0 bg-text-secondary/30" />
                  {s}
                </li>
              ))}
            </ul>

            {/* Remedy */}
            {state.remedy && (
              <div className="bg-accent/5 border border-accent/20 rounded-xl p-4">
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="material-symbols-outlined text-accent text-sm">healing</span>
                  <h4 className="text-[10px] font-bold uppercase tracking-widest text-accent">
                    {t('npk.remedy')}
                  </h4>
                </div>
                <p className="text-sm text-text-primary leading-relaxed">{state.remedy}</p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
