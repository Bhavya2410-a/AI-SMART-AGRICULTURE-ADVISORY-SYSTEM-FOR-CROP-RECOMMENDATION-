import { useLanguage } from '../context/LanguageContext';

function ConditionBadge({ condition }) {
  const colors = {
    Good: 'bg-accent/10 text-accent border border-accent/20',
    Moderate: 'bg-secondary/10 text-secondary border border-secondary/20',
    Poor: 'bg-error/10 text-error border border-error/20',
  };

  return (
    <span
      className={`inline-block px-3.5 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-widest ${
        colors[condition] || 'bg-surface-bright text-text-secondary border border-text-secondary/10'
      }`}
    >
      {condition}
    </span>
  );
}

function PropertyCard({ icon, label, value }) {
  return (
    <div className="bg-surface-lowest rounded-2xl p-4 flex items-start gap-3 transition-all duration-200 hover:bg-surface-hover">
      <span className="text-2xl shrink-0">{icon}</span>
      <div className="min-w-0">
        <p className="text-[10px] font-bold uppercase tracking-widest text-text-secondary">{label}</p>
        <p className="text-text-primary font-bold mt-1 text-lg">{value}</p>
      </div>
    </div>
  );
}

function CropCard({ crop }) {
  const confidence = parseInt(crop.confidence, 10) || 0;

  return (
    <div className="bg-surface-lowest rounded-2xl p-4 hover:bg-surface-hover transition-all duration-200">
      <div className="flex items-center gap-2.5 mb-3">
        <span className="text-2xl">{crop.emoji}</span>
        <span className="text-text-primary font-semibold">{crop.name}</span>
      </div>
      <div className="w-full bg-surface-bright rounded-full h-2.5 overflow-hidden">
        <div
          className="bg-accent h-2.5 rounded-full transition-all duration-700 ease-out"
          style={{ width: `${confidence}%` }}
        />
      </div>
      <p className="text-text-secondary text-xs font-medium mt-1.5 text-right">{confidence}%</p>
    </div>
  );
}

export default function AnalysisResult({ result }) {
  const { t } = useLanguage();

  if (!result) return null;

  return (
    <div className="bg-surface-card rounded-2xl ghost-border overflow-hidden">
      {/* Header */}
      <div className="p-6 md:p-8 border-b border-text-secondary/5">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <h2 className="text-2xl md:text-3xl font-black tracking-tight text-text-primary">{result.soil_type}</h2>
          <ConditionBadge condition={result.soil_condition} />
        </div>
      </div>

      <div className="p-6 md:p-8 space-y-8">
        {/* Properties Grid */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <span className="w-1.5 h-1.5 rounded-full bg-accent" />
            <h3 className="text-[10px] font-bold uppercase tracking-widest text-text-secondary">
              {t('soil.condition')}
            </h3>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            <PropertyCard
              icon="🧪"
              label={t('soil.ph')}
              value={result.ph_estimate}
            />
            <PropertyCard
              icon="💧"
              label={t('soil.moisture')}
              value={result.moisture}
            />
            <PropertyCard
              icon="🌿"
              label={t('soil.organicMatter')}
              value={result.organic_matter}
            />
          </div>
        </div>

        {/* Irrigation Recommendation */}
        <div className="bg-accent/5 border border-accent/20 rounded-2xl p-5">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center shrink-0">
              <span className="material-symbols-outlined text-accent">water_drop</span>
            </div>
            <div>
              <p className="text-sm font-bold text-accent uppercase tracking-wide">
                {t('soil.irrigation')}
              </p>
              <p className="text-sm text-text-secondary mt-1.5 leading-relaxed">
                {result.irrigation_recommendation}
              </p>
            </div>
          </div>
        </div>

        {/* Weather Suitability */}
        {result.weather_suitability && (
          <div className="flex items-start gap-3 text-sm text-text-secondary bg-surface-lowest rounded-2xl p-4">
            <span className="shrink-0 text-xl">🌤️</span>
            <p className="leading-relaxed">
              <span className="font-bold text-text-primary">{t('soil.weather')}:</span>{' '}
              {result.weather_suitability}
            </p>
          </div>
        )}

        {/* Top Crops */}
        {result.top_crops && result.top_crops.length > 0 && (
          <div>
            <div className="flex items-center gap-2 mb-4">
              <span className="w-1.5 h-1.5 rounded-full bg-accent" />
              <h3 className="text-[10px] font-bold uppercase tracking-widest text-text-secondary">
                {t('soil.topCrops')}
              </h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {result.top_crops.map((crop, i) => (
                <CropCard key={i} crop={crop} />
              ))}
            </div>
          </div>
        )}

        {/* Summary */}
        {result.summary && (
          <div>
            <div className="flex items-center gap-2 mb-4">
              <span className="w-1.5 h-1.5 rounded-full bg-accent" />
              <h3 className="text-[10px] font-bold uppercase tracking-widest text-text-secondary">
                {t('soil.summary')}
              </h3>
            </div>
            <blockquote className="bg-surface-lowest border-l-4 border-accent rounded-r-2xl p-5 text-text-primary text-sm leading-relaxed italic">
              {result.summary}
            </blockquote>
          </div>
        )}
      </div>
    </div>
  );
}
