import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from './context/ThemeContext';
import { LanguageProvider } from './context/LanguageContext';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import Layout from './components/Layout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import SoilAnalysis from './pages/SoilAnalysis';
import SoilTypes from './pages/SoilTypes';
import NPKGuide from './pages/NPKGuide';
import Advisory from './pages/Advisory';
import Voice from './pages/Voice';
import Profile from './pages/Profile';
import Help from './pages/Help';

export default function App() {
  return (
    <BrowserRouter>
      <ThemeProvider>
        <LanguageProvider>
          <AuthProvider>
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route
                path="/"
                element={
                  <ProtectedRoute>
                    <Layout>
                      <Dashboard />
                    </Layout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/soil-scan"
                element={
                  <ProtectedRoute>
                    <Layout>
                      <SoilAnalysis />
                    </Layout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/soil-types"
                element={
                  <ProtectedRoute>
                    <Layout>
                      <SoilTypes />
                    </Layout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/npk-guide"
                element={
                  <ProtectedRoute>
                    <Layout>
                      <NPKGuide />
                    </Layout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/advisories"
                element={
                  <ProtectedRoute>
                    <Layout>
                      <Advisory />
                    </Layout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/voice"
                element={
                  <ProtectedRoute>
                    <Layout>
                      <Voice />
                    </Layout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/profile"
                element={
                  <ProtectedRoute>
                    <Layout>
                      <Profile />
                    </Layout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/help"
                element={
                  <ProtectedRoute>
                    <Layout>
                      <Help />
                    </Layout>
                  </ProtectedRoute>
                }
              />
            </Routes>
          </AuthProvider>
        </LanguageProvider>
      </ThemeProvider>
    </BrowserRouter>
  );
}
