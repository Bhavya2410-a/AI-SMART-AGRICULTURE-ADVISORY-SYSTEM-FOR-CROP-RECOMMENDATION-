import { NavLink } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';

const navItems = [
  { to: '/', labelKey: 'nav.dashboard', icon: 'dashboard' },
  { to: '/soil-scan', labelKey: 'nav.soilScan', icon: 'search' },
  { to: '/soil-types', labelKey: 'nav.soilTypes', icon: 'layers' },
  { to: '/npk-guide', labelKey: 'nav.npkGuide', icon: 'bar_chart' },
  { to: '/advisories', labelKey: 'nav.advisories', icon: 'notifications' },
  { to: '/voice', labelKey: 'nav.voice', icon: 'mic' },
  { to: '/profile', labelKey: 'nav.profile', icon: 'person' },
  { to: '/help', labelKey: 'nav.help', icon: 'help' },
];

export default function Sidebar() {
  const { t } = useLanguage();

  return (
    <aside className="hidden md:flex flex-col fixed left-0 top-0 bottom-0 z-50 w-64 bg-surface-card ghost-border border-t-0 border-b-0 border-l-0 overflow-hidden">
      {/* Subtle nature background */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.03]">
        <img
          src="https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=400&q=30"
          alt=""
          className="w-full h-full object-cover"
        />
      </div>
      <div className="absolute inset-0 pointer-events-none bg-gradient-to-b from-surface-card via-surface-card/95 to-surface-card" />

      {/* Branding */}
      <div className="h-16 flex items-center gap-3 px-6 border-b border-border relative z-10">
        <div className="w-9 h-9 rounded-xl bg-accent/15 flex items-center justify-center">
          <span className="material-symbols-outlined text-accent" style={{ fontSize: '20px' }}>eco</span>
        </div>
        <div className="flex flex-col">
          <span className="text-lg font-bold text-accent tracking-tight">KrishiMitra</span>
          <span className="text-[10px] uppercase tracking-widest text-text-secondary">Digital Agronomist</span>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex flex-col gap-1 p-3 mt-2 flex-1 relative z-10">
        <span className="text-[10px] uppercase tracking-widest text-text-secondary font-semibold px-3 mb-2">
          Navigation
        </span>
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === '/'}
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all duration-200 group ${
                isActive
                  ? 'bg-accent/10 text-accent font-semibold shadow-sm shadow-accent/5'
                  : 'text-text-primary opacity-70 hover:bg-surface-hover hover:opacity-100'
              }`
            }
          >
            {({ isActive }) => (
              <>
                <span className={`material-symbols-outlined text-[20px] transition-transform duration-200 ${isActive ? '' : 'group-hover:scale-110'}`}>
                  {item.icon}
                </span>
                <span className="text-sm">{t(item.labelKey)}</span>
                {isActive && (
                  <span className="ml-auto w-1.5 h-1.5 rounded-full bg-accent" />
                )}
              </>
            )}
          </NavLink>
        ))}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-border relative z-10">
        <div className="flex items-center justify-center gap-2">
          <span className="material-symbols-outlined text-accent/40" style={{ fontSize: '14px' }}>spa</span>
          <p className="text-[10px] text-text-secondary text-center uppercase tracking-widest">
            Earth-Tone Precision
          </p>
        </div>
      </div>
    </aside>
  );
}
