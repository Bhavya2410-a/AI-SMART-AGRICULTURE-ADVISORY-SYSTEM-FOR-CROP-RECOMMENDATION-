const npkData = {
  nitrogen: {
    symbol: 'N',
    name: 'Nitrogen',
    role: 'Essential for leaf growth and chlorophyll',
    color: '#16a34a',
    states: [
      {
        condition: 'Deficient',
        color: '#FFFFCC',
        leafColor: 'Pale yellow-green',
        description: 'Older leaves turn pale yellow-green, starting from tips',
        symptoms: [
          'Stunted growth',
          'Pale yellow older leaves',
          'Premature leaf drop',
        ],
        remedy: 'Apply urea, ammonium sulfate, or organic compost',
      },
      {
        condition: 'Sufficient',
        color: '#228B22',
        leafColor: 'Dark green',
        description: 'Leaves show healthy dark green color with vigorous growth',
        symptoms: [
          'Healthy dark green foliage',
          'Strong stem growth',
          'Good tillering',
        ],
      },
      {
        condition: 'Excess',
        color: '#006400',
        leafColor: 'Very dark green',
        description: 'Excessively dark leaves, delayed maturity',
        symptoms: [
          'Very dark green soft leaves',
          'Delayed flowering',
          'Susceptible to disease',
        ],
        remedy: 'Reduce nitrogen application, increase potassium',
      },
    ],
  },
  phosphorus: {
    symbol: 'P',
    name: 'Phosphorus',
    role: 'Essential for root development and flowering',
    color: '#9333ea',
    states: [
      {
        condition: 'Deficient',
        color: '#8B008B',
        leafColor: 'Purple/reddish tint',
        description: 'Leaves develop purple or reddish discoloration',
        symptoms: [
          'Purple/red tint on leaves',
          'Poor root development',
          'Delayed maturity',
        ],
        remedy: 'Apply DAP, single superphosphate, or bone meal',
      },
      {
        condition: 'Sufficient',
        color: '#228B22',
        leafColor: 'Dark green',
        description: 'Good root system and normal flowering',
        symptoms: [
          'Healthy dark green leaves',
          'Strong root system',
          'Normal flowering',
        ],
      },
      {
        condition: 'Excess',
        color: '#B8860B',
        leafColor: 'Interveinal chlorosis',
        description: 'Can cause zinc and iron deficiency symptoms',
        symptoms: [
          'Yellowing between leaf veins',
          'Zinc deficiency signs',
          'Iron chlorosis',
        ],
        remedy: 'Stop phosphorus application, add zinc sulfate',
      },
    ],
  },
  potassium: {
    symbol: 'K',
    name: 'Potassium',
    role: 'Essential for disease resistance and water regulation',
    color: '#ea580c',
    states: [
      {
        condition: 'Deficient',
        color: '#8B4513',
        leafColor: 'Brown scorched edges',
        description: 'Leaf edges and tips turn brown (scorching effect)',
        symptoms: [
          'Brown scorched leaf edges',
          'Weak stems',
          'Poor fruit quality',
        ],
        remedy: 'Apply muriate of potash (MOP) or sulfate of potash (SOP)',
      },
      {
        condition: 'Sufficient',
        color: '#228B22',
        leafColor: 'Healthy green edges',
        description: 'Leaves have healthy green margins with good structure',
        symptoms: [
          'Strong stems',
          'Healthy green leaf edges',
          'Good fruit quality',
        ],
      },
      {
        condition: 'Excess',
        color: '#DAA520',
        leafColor: 'Marginal necrosis',
        description: 'Can cause magnesium and calcium deficiency',
        symptoms: [
          'Magnesium deficiency symptoms',
          'Calcium uptake issues',
          'Salt burn on roots',
        ],
        remedy: 'Leach soil with water, add magnesium sulfate',
      },
    ],
  },
};

export default npkData;
