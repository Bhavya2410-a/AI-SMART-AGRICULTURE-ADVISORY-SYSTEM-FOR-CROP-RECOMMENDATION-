import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import { apiFetch } from '../lib/api';

const SOIL_COLORS = {
  'Alluvial': '#C2B280',
  'Black': '#2C2C2C',
  'Red': '#CD5C5C',
  'Laterite': '#B22222',
  'Desert': '#EDC9AF',
  'Mountain': '#4A7C59',
  'Peaty': '#3E2723',
  'Saline': '#F5F5DC',
};

function getSoilColor(soilType) {
  if (!soilType) return 'var(--accent)';
  for (const [key, color] of Object.entries(SOIL_COLORS)) {
    if (soilType.toLowerCase().includes(key.toLowerCase())) return color;
  }
  return 'var(--accent)';
}

export default function RecentScans() {
  const { t } = useLanguage();
  const [scans, setScans] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiFetch('/soil/history?page=1&limit=5')
      .then((data) => {
        setScans(data.analyses || data || []);
      })
      .catch(() => {
        setScans([]);
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="bg-surface-card ghost-border rounded-2xl overflow-hidden animate-pulse">
        <div className="p-6">
          <div className="h-4 bg-surface-hover rounded w-1/3 mb-4" />
        </div>
        <div className="px-6 pb-6 space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-16 bg-surface-hover rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-surface-card ghost-border rounded-2xl overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between p-6 pb-0">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-accent" />
          <h3 className="text-[10px] font-bold uppercase tracking-[0.15em] text-text-secondary">
            {t('dashboard.recentScans')}
          </h3>
        </div>
        {scans.length > 0 && (
          <Link
            to="/soil-scan"
            className="text-[10px] font-bold uppercase tracking-[0.15em] text-accent hover:underline flex items-center gap-1"
          >
            {t('common.viewAll')}
            <span className="material-symbols-outlined text-xs">arrow_forward</span>
          </Link>
        )}
      </div>

      {scans.length === 0 ? (
        <div className="text-center py-10 px-6">
          <div className="relative w-20 h-20 mx-auto mb-4">
            <img
              src="https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=200&q=80"
              alt=""
              className="w-full h-full object-cover rounded-2xl opacity-40"
            />
            <div className="absolute inset-0 bg-surface-card/50 rounded-2xl flex items-center justify-center">
              <span className="material-symbols-outlined text-accent text-3xl">search</span>
            </div>
          </div>
          <p className="text-sm text-text-secondary mb-5 leading-relaxed">
            {t('dashboard.noScans')}
          </p>
          <Link
            to="/soil-scan"
            className="inline-block bg-accent text-accent-on text-sm font-bold px-6 py-3 rounded-full hover:brightness-110 active:scale-[0.98] transition-all shadow-lg shadow-accent/20"
          >
            {t('dashboard.startScan')}
          </Link>
        </div>
      ) : (
        <div className="p-4 pt-4 space-y-2">
          {scans.map((scan, index) => {
            let soilType = '';
            let condition = '';
            try {
              const raw = scan.result || scan.result_json;
              const result = typeof raw === 'string' ? JSON.parse(raw) : raw;
              soilType = result?.soil_type || result?.soilType || '';
              condition = result?.condition || '';
            } catch {
              // ignore parse errors
            }

            const date = scan.created_at
              ? new Date(scan.created_at).toLocaleDateString(undefined, {
                  month: 'short',
                  day: 'numeric',
                })
              : '';

            const soilColor = getSoilColor(soilType);

            return (
              <Link
                key={scan.id || scan.created_at}
                to="/soil-scan"
                className="flex items-center gap-3 p-3 rounded-xl hover:bg-surface-hover/50 transition-all group"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                {/* Soil color indicator */}
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 relative overflow-hidden"
                  style={{ backgroundColor: `${soilColor}20` }}
                >
                  <div
                    className="absolute bottom-0 left-0 right-0 h-1 rounded-full"
                    style={{ backgroundColor: soilColor }}
                  />
                  <span className="material-symbols-outlined group-hover:scale-110 transition-transform" style={{ fontSize: '18px', color: soilColor }}>
                    landscape
                  </span>
                </div>

                <div className="min-w-0 flex-1">
                  <p className="text-sm font-bold text-text-primary truncate">
                    {soilType || t('soil.soilType')}
                  </p>
                  {condition && (
                    <span className="inline-block mt-0.5 text-[10px] font-bold uppercase tracking-[0.15em] text-accent bg-accent/10 px-2 py-0.5 rounded-full">
                      {condition}
                    </span>
                  )}
                </div>
                <div className="flex flex-col items-end shrink-0">
                  <span className="text-[10px] font-bold uppercase tracking-[0.15em] text-text-secondary">
                    {date}
                  </span>
                  <span className="material-symbols-outlined text-text-secondary/40 text-sm mt-1 group-hover:text-accent group-hover:translate-x-0.5 transition-all">
                    chevron_right
                  </span>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
