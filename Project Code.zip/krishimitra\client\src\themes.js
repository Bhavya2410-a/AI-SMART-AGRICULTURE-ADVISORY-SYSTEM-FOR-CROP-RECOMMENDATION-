const themes = [
  { id: 'dark', name: 'Dark', color: '#0f141a', dotColor: '#4be277' },
  { id: 'light', name: 'Light', color: '#f4f1ec', dotColor: '#f4f1ec' },
  { id: 'forest', name: 'Forest', color: '#071209', dotColor: '#fbbf24' },
];
export default themes;
